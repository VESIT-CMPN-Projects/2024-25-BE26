import '../data/models/project_model.dart';

/// A list of dummy project data for testing purposes.
///
/// Contains sample civil engineering projects with different statuses
/// to test project listing, filtering, and detail views.
final List<ProjectModel> mockProjects = [
  // Active road construction project
  ProjectModel(
    id: 1,
    title: 'Kamptee Highway Extension',
    description: 'Extension of NH-7 highway section near Kamptee with cement concrete road construction spanning 15km.',
    startDate: DateTime(2025, 1, 10),
    endDate: DateTime(2025, 7, 15),
    status: 'In Progress',
  ),
  
  // Completed project
  ProjectModel(
    id: 2,
    title: 'Nagpur City Flyover',
    description: 'Construction of a 2.5km flyover connecting Cotton Market to Automotive Square in Nagpur.',
    startDate: DateTime(2024, 5, 15),
    endDate: DateTime(2025, 1, 30),
    status: 'Completed',
  ),
  
  // Pending project
  ProjectModel(
    id: 3,
    title: 'Koradi Road Widening',
    description: 'Widening of Koradi Road from 2-lane to 4-lane with median and drainage system construction.',
    startDate: DateTime(2025, 3, 1),
    endDate: DateTime(2025, 9, 30),
    status: 'Pending',
  ),
  
  // Delayed project
  ProjectModel(
    id: 4,
    title: 'Ramtek Temple Access Road',
    description: 'Construction of cement concrete approach road to Ramtek Temple including parking facilities.',
    startDate: DateTime(2024, 11, 15),
    endDate: DateTime(2025, 3, 30),
    status: 'Delayed',
  ),
  
  // Recently started project
  ProjectModel(
    id: 5,
    title: 'Butibori Industrial Area Internal Roads',
    description: 'Development of internal road network for Butibori MIDC Phase II with cement concrete roads and drainage.',
    startDate: DateTime(2025, 2, 1),
    endDate: DateTime(2025, 8, 15),
    status: 'In Progress',
  ),
];

/// Find a project by ID.
///
/// This function retrieves a project with the specified ID from the mock data.
ProjectModel? getProjectById(int id) {
  try {
    return mockProjects.firstWhere((project) => project.id == id);
  } catch (e) {
    return null; // Project not found
  }
}

/// Find projects by status.
///
/// This function retrieves all projects with the specified status from the mock data.
List<ProjectModel> getProjectsByStatus(String status) {
  return mockProjects.where((project) => project.status == status).toList();
}