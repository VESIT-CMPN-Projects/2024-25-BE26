import '../data/models/inventory_model.dart';

/// A list of dummy inventory items for testing purposes.
///
/// Contains sample construction materials with varying quantities
/// to test inventory tracking, alerts, and management functionality.
final List<InventoryModel> mockInventory = [
  // Common construction materials
  const InventoryModel(
    id: 1,
    materialName: 'Cement (OPC 53 Grade)',
    quantity: 1500.0, // in bags
    alertThreshold: 300.0,
  ),
  
  const InventoryModel(
    id: 2,
    materialName: 'Sand (Fine)',
    quantity: 450.0, // in cubic meters
    alertThreshold: 100.0,
  ),
  
  const InventoryModel(
    id: 3,
    materialName: 'Aggregate (20mm)',
    quantity: 800.0, // in cubic meters
    alertThreshold: 200.0,
  ),
  
  // Low stock item
  const InventoryModel(
    id: 4,
    materialName: 'Steel Reinforcement Bars',
    quantity: 25.0, // in tonnes
    alertThreshold: 50.0,
  ),
  
  const InventoryModel(
    id: 5,
    materialName: 'Bitumen',
    quantity: 120.0, // in drums
    alertThreshold: 30.0,
  ),
  
  const InventoryModel(
    id: 6,
    materialName: 'Concrete Admixture',
    quantity: 85.0, // in liters
    alertThreshold: 20.0,
  ),
  
  // Almost at threshold
  const InventoryModel(
    id: 7,
    materialName: 'Traffic Safety Cones',
    quantity: 51.0, // in units
    alertThreshold: 50.0,
  ),
  
  const InventoryModel(
    id: 8,
    materialName: 'Form Work Panels',
    quantity: 200.0, // in square meters
    alertThreshold: 75.0,
  ),
];

/// Get all inventory items that are below their alert threshold.
///
/// Returns a list of inventory items that need to be restocked.
List<InventoryModel> getLowStockItems() {
  return mockInventory.where((item) => item.isLow).toList();
}

/// Find an inventory item by ID.
///
/// This function retrieves an inventory item with the specified ID from the mock data.
InventoryModel? getInventoryItemById(int id) {
  try {
    return mockInventory.firstWhere((item) => item.id == id);
  } catch (e) {
    return null; // Item not found
  }
}