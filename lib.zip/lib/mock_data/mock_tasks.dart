import '../data/models/task_model.dart';

/// A list of dummy tasks for testing purposes.
///
/// Contains sample tasks associated with different projects and with varying statuses
/// to test task management, filtering, and timeline functionality.
final List<TaskModel> mockTasks = [
  // Tasks for Kamptee Highway Extension (Project ID: 1)
  TaskModel(
    id: 1,
    projectId: 1,
    title: 'Site Survey and Marking',
    description: 'Complete topographical survey and marking of the 15km stretch for the Kamptee Highway Extension project.',
    deadline: DateTime(2025, 1, 25),
    status: 'Completed',
  ),
  
  TaskModel(
    id: 2,
    projectId: 1,
    title: 'Land Clearing and Grading',
    description: 'Clear vegetation and grade the road path according to the approved design specifications.',
    deadline: DateTime(2025, 2, 15),
    status: 'In Progress',
  ),
  
  TaskModel(
    id: 3,
    projectId: 1,
    title: 'Foundation and Sub-base Preparation',
    description: 'Prepare the sub-base with proper compaction and material layering as per specifications.',
    deadline: DateTime(2025, 3, 10),
    status: 'Pending',
  ),
  
  // Tasks for Nagpur City Flyover (Project ID: 2)
  TaskModel(
    id: 4,
    projectId: 2,
    title: 'Final Inspection',
    description: 'Conduct final quality and safety inspection of the completed flyover before handover.',
    deadline: DateTime(2025, 1, 25),
    status: 'Completed',
  ),
  
  TaskModel(
    id: 5,
    projectId: 2,
    title: 'Documentation Compilation',
    description: 'Compile all project documentation, warranties, and maintenance guidelines for handover.',
    deadline: DateTime(2025, 1, 30),
    status: 'Completed',
  ),
  
  // Tasks for Koradi Road Widening (Project ID: 3)
  TaskModel(
    id: 6,
    projectId: 3,
    title: 'Utility Relocation Planning',
    description: 'Coordinate with municipal authorities for planning the relocation of water, electricity, and telecom lines.',
    deadline: DateTime(2025, 2, 25),
    status: 'In Progress',
  ),
  
  // Tasks for Ramtek Temple Access Road (Project ID: 4)
  TaskModel(
    id: 7,
    projectId: 4,
    title: 'Drainage System Installation',
    description: 'Install proper drainage systems along the temple access road to prevent water logging during monsoon.',
    deadline: DateTime(2025, 1, 15),
    status: 'Delayed',
  ),
  
  TaskModel(
    id: 8,
    projectId: 4,
    title: 'Concrete Pouring for Road Section 2',
    description: 'Complete concrete pouring for the second 1km section of the temple access road.',
    deadline: DateTime(2025, 2, 10),
    status: 'Pending',
  ),
  
  // Tasks for Butibori Industrial Area (Project ID: 5)
  TaskModel(
    id: 9,
    projectId: 5,
    title: 'Material Delivery Scheduling',
    description: 'Coordinate and schedule delivery of cement, aggregate, and other materials to the Butibori site.',
    deadline: DateTime(2025, 2, 10),
    status: 'Completed',
  ),
  
  TaskModel(
    id: 10,
    projectId: 5,
    title: 'Equipment Deployment',
    description: 'Deploy concrete mixers, pavers, and compactors to the Butibori site for internal road construction.',
    deadline: DateTime(2025, 2, 15),
    status: 'In Progress',
  ),
];

/// Find tasks by project ID.
///
/// This function retrieves all tasks associated with a specific project.
List<TaskModel> getTasksByProjectId(int projectId) {
  return mockTasks.where((task) => task.projectId == projectId).toList();
}

/// Find tasks by status.
///
/// This function retrieves all tasks with a specific status.
List<TaskModel> getTasksByStatus(String status) {
  return mockTasks.where((task) => task.status == status).toList();
}

/// Find overdue tasks.
///
/// This function retrieves all tasks that are past their deadline but not completed.
List<TaskModel> getOverdueTasks() {
  final now = DateTime.now();
  return mockTasks.where((task) => 
    task.deadline.isBefore(now) && task.status != 'Completed'
  ).toList();
}