import '../data/models/user_model.dart';

/// A list of dummy user accounts for testing purposes.
///
/// Contains sample users with different roles (Worker, Accountant, Manager, Admin, Developer)
/// to test login functionality and role-based navigation.
final List<UserModel> mockUsers = [
  // Worker role
  const UserModel(
    id: 1,
    name: 'Rajesh Kumar',
    email: 'rajesh.skg.infra@gmail.com',
    password: 'worker123',
    role: 'Worker',
    avatarUrl: 'https://ui-avatars.com/api/?name=Rajesh+Kumar&background=FFC107&color=000',
  ),
  
  // Accountant role
  const UserModel(
    id: 2,
    name: 'Priya Sharma',
    email: 'priya.skg.infra@gmail.com',
    password: 'accountant123',
    role: 'Accountant',
    avatarUrl: 'https://ui-avatars.com/api/?name=Priya+Sharma&background=FFC107&color=000',
  ),
  
  // Manager role
  const UserModel(
    id: 3,
    name: 'Amit Patel',
    email: 'amit@skgurbaxani.com',
    password: 'manager123',
    role: 'Manager',
    avatarUrl: 'https://ui-avatars.com/api/?name=Amit+Patel&background=4CAF50&color=fff',
  ),
  
  // Admin role
  const UserModel(
    id: 4,
    name: 'Sunita Deshmukh',
    email: 'sunita@skgurbaxani.com',
    password: 'admin123',
    role: 'Admin',
    avatarUrl: 'https://ui-avatars.com/api/?name=Sunita+Deshmukh&background=9C27B0&color=fff',
  ),
  
  // Developer role
  const UserModel(
    id: 5,
    name: 'Vikram Joshi',
    email: 'vikram@skgurbaxani.com',
    password: 'developer123',
    role: 'Developer',
    avatarUrl: 'https://ui-avatars.com/api/?name=Vikram+Joshi&background=F44336&color=fff',
  ),
  
  // Additional Worker for testing
  const UserModel(
    id: 6,
    name: 'Deepak Singh',
    email: 'deepak@skgurbaxani.com',
    password: 'worker456',
    role: 'Worker',
    avatarUrl: 'https://ui-avatars.com/api/?name=Deepak+Singh&background=0D8ABC&color=fff',
  ),
  
  // Additional Manager for testing
  const UserModel(
    id: 7,
    name: 'Neha Kapoor',
    email: 'neha@skgurbaxani.com',
    password: 'manager456',
    role: 'Manager',
    avatarUrl: 'https://ui-avatars.com/api/?name=Neha+Kapoor&background=4CAF50&color=fff',
  ),
];

/// Find a user by email.
///
/// This function retrieves a user with the specified email from the mock data.
UserModel? findUserByEmail(String email) {
  try {
    return mockUsers.firstWhere((user) => user.email.toLowerCase() == email.toLowerCase());
  } catch (e) {
    return null; // User not found
  }
}

/// Find a user by credentials (email and password).
///
/// This function simulates an authentication process by finding a user with 
/// the specified email and password. Returns the user if credentials match,
/// otherwise returns null.
UserModel? findUserByCredentials(String email, String password) {
  try {
    return mockUsers.firstWhere(
      (user) => 
        user.email.toLowerCase() == email.toLowerCase() && 
        user.password == password
    );
  } catch (e) {
    return null; // User not found or password incorrect
  }
}