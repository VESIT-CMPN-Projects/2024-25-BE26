import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../ui/screens/auth/login_screen.dart';
import '../../ui/screens/auth/profile_screen.dart';
import '../../ui/screens/dashboard/dashboard_screen.dart';
import '../../ui/screens/inventory/inventory_screen.dart';
import '../../ui/screens/projects/projects_screen.dart';
import '../../ui/screens/tasks/tasks_screen.dart';
import '../../ui/screens/user_management/user_management_screen.dart';
import '../../ui/screens/settings/settings_screen.dart';
import 'route_paths.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: RoutePaths.login,
    routes: [
      // Auth routes
      GoRoute(
        path: RoutePaths.login,
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: RoutePaths.logout,
        redirect: (_, __) => RoutePaths.login,
      ),
      GoRoute(
        path: RoutePaths.profile,
        builder: (context, state) => const ProfileScreen(),
      ),
      
      // Main routes
      GoRoute(
        path: RoutePaths.dashboard,
        builder: (context, state) => const DashboardScreen(),
      ),
      GoRoute(
        path: RoutePaths.inventory,
        builder: (context, state) => const InventoryScreen(),
      ),
      GoRoute(
        path: RoutePaths.projects,
        builder: (context, state) => const ProjectsScreen(),
      ),
      GoRoute(
        path: RoutePaths.tasks,
        builder: (context, state) => const TasksScreen(),
      ),
      GoRoute(
        path: RoutePaths.userManagement,
        builder: (context, state) => const UserManagementScreen(),
      ),
      GoRoute(
        path: RoutePaths.settings,
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Text(
          'Page not found: ${state.uri.toString()}',
          style: Theme.of(context).textTheme.titleLarge,
        ),
      ),
    ),
  );
}