class RoutePaths {
  // Auth routes
  static const String login = '/login';
  static const String logout = '/logout';
  static const String profile = '/user-profile';
  
  // Main module routes
  static const String dashboard = '/dashboard';
  static const String inventory = '/inventory';
  static const String projects = '/projects';
  static const String tasks = '/tasks';
  static const String userManagement = '/user-management';
  static const String settings = '/settings';
  static const String system = '/system';
}