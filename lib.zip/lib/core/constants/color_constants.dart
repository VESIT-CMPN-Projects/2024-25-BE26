import 'package:flutter/material.dart';

/// Color constants for the Mobile Operations App.
/// 
/// This class defines all the colors used throughout the app to maintain
/// a consistent color scheme and make global color changes easy.
class ColorConstants {
  // Primary colors
  static const Color primary = Color(0xFF3282B8);
  static const Color secondary = Color(0xFF0F4C75);
  static const Color accent = Color(0xFF00A8CC);
  
  // Background colors
  static const Color background = Color(0xFF1A1A2E);
  static const Color cardBackground = Color(0xFF2C2C3E);
  static const Color surfaceBackground = Color(0xFF252538);
  
  // Text colors
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Colors.white70;
  static const Color textHint = Colors.white54;
  
  // Status colors
  static const Color success = Color(0xFF4CAF50);
  static const Color error = Color(0xFFE57373);
  static const Color warning = Color(0xFFFFB74D);
  static const Color info = Color(0xFF64B5F6);
  
  // Border and divider colors
  static const Color border = Color(0xFF3A3A4E);
  static const Color divider = Color(0xFF3A3A4E);
  
  // Disabled state colors
  static const Color disabled = Color(0xFF636387);
  static const Color disabledButton = Color(0xFF3F3F55);
  
  // Misc colors
  static const Color shadow = Color(0x40000000);
  static const Color overlay = Color(0x991A1A2E);
  
  // Gradient colors
  static const List<Color> primaryGradient = [
    Color(0xFF3282B8),
    Color(0xFF0F4C75),
  ];
  
  // Material color for theme
  static const MaterialColor primarySwatch = MaterialColor(
    0xFF3282B8,
    <int, Color>{
      50: Color(0xFFE6F1F8),
      100: Color(0xFFBFDDED),
      200: Color(0xFF95C7E2),
      300: Color(0xFF6AB1D6),
      400: Color(0xFF4A9FCE),
      500: Color(0xFF3282B8),
      600: Color(0xFF2D7AB1),
      700: Color(0xFF266FA8),
      800: Color(0xFF1F65A0),
      900: Color(0xFF135291),
    },
  );
}