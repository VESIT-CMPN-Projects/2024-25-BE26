import 'package:flutter/material.dart';

class AppColors {
  // Primary colors
  static const Color primaryDark = Color(0xFF0A192F);
  static const Color primaryBlue = Color(0xFF1E88E5);
  static const Color primaryLight = Color(0xFFFFFFFF);
  static const Color accentGold = Color(0xFFFFD700);
  
  // Accent colors
  static const Color accentTeal = Color(0xFF4ECDC4);
  static const Color accentPink = Color(0xFFFF6B6B);
  static const Color accentYellow = Color(0xFFFFD166);
  
  // Background colors
  static const Color backgroundDark = Color(0xFF121212);
  static const Color backgroundMedium = Color(0xFF1E1E1E);
  static const Color backgroundLight = Color(0xFF2D2D2D);
  
  // Text colors
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFB3B3B3);
  static const Color textDisabled = Color(0xFF666666);
  
  // Status colors
  static const Color success = Color(0xFF4CAF50);
  static const Color error = Color(0xFFF44336);
  static const Color warning = Color(0xFFFF9800);
  static const Color info = Color(0xFF2196F3);
}