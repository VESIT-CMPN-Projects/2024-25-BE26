import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/navigation/route_paths.dart';
import '../../../data/models/user_model.dart';
import '../../../data/providers/auth_provider.dart';
import 'package:provider/provider.dart';

class AppDrawer extends StatelessWidget {
  final String currentRoute;

  const AppDrawer({
    Key? key,
    required this.currentRoute,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get the current user from the auth provider
    final authProvider = Provider.of<AuthProvider>(context);
    final UserModel? currentUser = authProvider.currentUser;
    
    // If user is not logged in or data is not available, show loading state
    if (currentUser == null) {
      return const Drawer(
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Drawer(
      child: Column(
        children: [
          // Drawer Header
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.8),
            ),
            currentAccountPicture: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(
                Icons.person,
                size: 36,
                color: Colors.black54,
              ),
            ),
            accountName: Text(currentUser.name),
            accountEmail: Text(currentUser.email),
          ),
          
          // Navigation Items including logout - All in the same ListView
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ..._buildNavigationItems(context, currentUser.role),
                // Add a divider before logout
                const Divider(),
                // Logout - Available to all users
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Logout'),
                  onTap: () {
                    authProvider.logout();
                    context.go(RoutePaths.login);
                  },
                ),
                const Divider(),
              ],
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  // Build list of navigation items based on user role
  List<Widget> _buildNavigationItems(BuildContext context, String role) {
    // Common items available to all roles
    final List<Widget> items = [
      _buildDrawerItem(
        context,
        Icons.dashboard_outlined,
        'Dashboard',
        RoutePaths.dashboard,
      ),
    ];

    // Add role-specific navigation items based on the PRD's access matrix
    switch (role.toLowerCase()) {
      case 'worker':
        // Workers can access: Dashboard, Task Planner
        items.addAll([
          _buildDrawerItem(
            context,
            Icons.task_alt_outlined,
            'Tasks',
            RoutePaths.tasks,
          ),
          const Divider(),
          _buildDrawerItem(
            context,
            Icons.person_outline,
            'Profile',
            RoutePaths.profile,
          ),
        ]);
        break;
        
      case 'accountant':
        // Accountants can access: Dashboard, Inventory, Task Planner
        items.addAll([
          _buildDrawerItem(
            context,
            Icons.task_alt_outlined,
            'Tasks',
            RoutePaths.tasks,
          ),
          _buildDrawerItem(
            context,
            Icons.inventory_2_outlined,
            'Inventory',
            RoutePaths.inventory,
          ),
          const Divider(),
          _buildDrawerItem(
            context,
            Icons.person_outline,
            'Profile',
            RoutePaths.profile,
          ),
        ]);
        break;
        
      case 'manager':
        // Managers can access: Dashboard, Project CRUD, Task Planner, Inventory
        items.addAll([
          _buildDrawerItem(
            context,
            Icons.engineering_outlined,
            'Projects',
            RoutePaths.projects,
          ),
          _buildDrawerItem(
            context,
            Icons.task_alt_outlined,
            'Tasks',
            RoutePaths.tasks,
          ),
          _buildDrawerItem(
            context,
            Icons.inventory_2_outlined,
            'Inventory',
            RoutePaths.inventory,
          ),
          const Divider(),
          _buildDrawerItem(
            context,
            Icons.person_outline,
            'Profile',
            RoutePaths.profile,
          ),
        ]);
        break;
        
      case 'admin':
        // Admins have access to everything except developer tools
        items.addAll([
          _buildDrawerItem(
            context,
            Icons.engineering_outlined,
            'Projects',
            RoutePaths.projects,
          ),
          _buildDrawerItem(
            context,
            Icons.task_alt_outlined,
            'Tasks',
            RoutePaths.tasks,
          ),
          _buildDrawerItem(
            context,
            Icons.inventory_2_outlined,
            'Inventory',
            RoutePaths.inventory,
          ),
          _buildDrawerItem(
            context,
            Icons.people_outline,
            'User Management',
            RoutePaths.userManagement,
          ),
          const Divider(),
          _buildDrawerItem(
            context,
            Icons.person_outline,
            'Profile',
            RoutePaths.profile,
          ),
          _buildDrawerItem(
            context,
            Icons.settings_outlined,
            'Settings',
            RoutePaths.settings,
          ),
        ]);
        break;
        
      case 'developer':
        // Developers have full access including system settings
        items.addAll([
          _buildDrawerItem(
            context,
            Icons.engineering_outlined,
            'Projects',
            RoutePaths.projects,
          ),
          _buildDrawerItem(
            context,
            Icons.task_alt_outlined,
            'Tasks',
            RoutePaths.tasks,
          ),
          _buildDrawerItem(
            context,
            Icons.inventory_2_outlined,
            'Inventory',
            RoutePaths.inventory,
          ),
          _buildDrawerItem(
            context,
            Icons.people_outline,
            'User Management',
            RoutePaths.userManagement,
          ),
          const Divider(),
          _buildDrawerItem(
            context,
            Icons.person_outline,
            'Profile',
            RoutePaths.profile,
          ),
          _buildDrawerItem(
            context,
            Icons.settings_outlined,
            'Settings',
            RoutePaths.settings,
          ),
          _buildDrawerItem(
            context,
            Icons.developer_mode_outlined,
            'System',
            RoutePaths.system,
          ),
        ]);
        break;
        
      default:
        // Fallback for unknown roles - limited access
        items.addAll([
          _buildDrawerItem(
            context,
            Icons.task_alt_outlined,
            'Tasks',
            RoutePaths.tasks,
          ),
          const Divider(),
          _buildDrawerItem(
            context,
            Icons.person_outline,
            'Profile',
            RoutePaths.profile,
          ),
        ]);
    }
    
    return items;
  }

  Widget _buildDrawerItem(
    BuildContext context,
    IconData icon,
    String title,
    String route,
  ) {
    final bool isSelected = currentRoute == route;
    
    return ListTile(
      leading: Icon(
        icon,
        color: isSelected ? Theme.of(context).colorScheme.primary : null,
      ),
      title: Text(
        title,
        style: TextStyle(
          color: isSelected ? Theme.of(context).colorScheme.primary : null,
          fontWeight: isSelected ? FontWeight.bold : null,
        ),
      ),
      onTap: () {
        Navigator.pop(context); // Close drawer
        if (currentRoute != route) {
          context.go(route);
        }
      },
      selected: isSelected,
    );
  }
}