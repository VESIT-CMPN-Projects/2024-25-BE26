import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:skg_mobile/core/navigation/route_paths.dart';
import 'package:skg_mobile/ui/widgets/common/app_drawer.dart';
import '../../../core/constants/app_constants.dart';
import '../../../data/providers/theme_provider.dart';
import '../../../data/repositories/auth_repository.dart';
import '../../theme/app_colors.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);
  
  @override
  State createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final List<String> _filterOptions = ['All Settings', 'Account', 'Appearance', 'Notifications', 'Integrations'];
  String _selectedFilter = 'All Settings';
  bool _isLoading = false;
  
  // Local state for settings
  bool _darkMode = true;
  bool _useSystemTheme = false;
  double _textSize = 1.0; // 1.0 is default, can be 0.8, 1.0, 1.2
  
  // Notification preferences
  bool _emailNotifications = true;
  bool _pushNotifications = true;
  bool _taskReminders = true;
  bool _inventoryAlerts = true;
  bool _projectUpdates = true;
  
  // Integration settings
  bool _syncWithERP = false;
  bool _enableCloudBackup = true;
  int _backupFrequency = 1; // 0: Daily, 1: Weekly, 2: Monthly
  
  // Account settings
  String _selectedLanguage = 'English';
  final List<String> _languages = ['English', 'Hindi', 'Marathi'];
  
  @override
  void initState() {
    super.initState();
    // Simulate loading settings from storage
    _loadSettings();
  }
  
  void _loadSettings() {
    setState(() {
      _isLoading = true;
    });
    
    // Simulate async loading
    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() {
        // In a real app, you would load these values from storage/preferences
        _isLoading = false;
      });
    });
  }
  
  void _saveSettings() {
    setState(() {
      _isLoading = true;
    });
    
    // Simulate saving settings
    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() {
        _isLoading = false;
      });
      
      // Show success snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Settings saved successfully'),
          backgroundColor: AppColors.primaryBlue,
          behavior: SnackBarBehavior.floating,
        ),
      );
    });
  }
  
  void _applyFilters() {
    // This would filter the settings sections based on the selected filter
    // For now, we'll just use this for UI state
  }
  
  Widget _buildSettingsSection(String title, List<Widget> children) {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 12),
            child: Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppColors.primaryBlue,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              children: children,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSettingItem({
    required String title,
    required Widget trailing,
    String? subtitle,
    IconData? icon,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: icon != null
          ? Icon(icon, color: AppColors.primaryBlue)
          : null,
      title: Text(title),
      subtitle: subtitle != null ? Text(subtitle) : null,
      trailing: trailing,
    );
  }
  
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    // Filter settings based on selected filter
    bool showAppearance = _selectedFilter == 'All Settings' || _selectedFilter == 'Appearance';
    bool showNotifications = _selectedFilter == 'All Settings' || _selectedFilter == 'Notifications';
    bool showIntegrations = _selectedFilter == 'All Settings' || _selectedFilter == 'Integrations';
    bool showAccount = _selectedFilter == 'All Settings' || _selectedFilter == 'Account';
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        actions: [
          if (_isLoading)
            Container(
              padding: const EdgeInsets.all(12),
              child: const SizedBox(
                height: 24,
                width: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadSettings,
            tooltip: 'Refresh Settings',
          ),
          PopupMenuButton(
            icon: const Icon(Icons.filter_list),
            tooltip: 'Filter Settings',
            onSelected: (value) {
              setState(() {
                _selectedFilter = value;
                _applyFilters();
              });
            },
            itemBuilder: (BuildContext context) {
              return _filterOptions.map((String option) {
                return PopupMenuItem(
                  value: option,
                  child: Row(
                    children: [
                      if (_selectedFilter == option)
                        const Icon(Icons.check, color: AppColors.primaryBlue)
                      else
                        const SizedBox(width: 24),
                      const SizedBox(width: 8),
                      Text(option),
                    ],
                  ),
                );
              }).toList();
            },
          ),
        ],
      ),
      // Add drawer to the Scaffold
      drawer: const AppDrawer(currentRoute: RoutePaths.settings),
      
      body: _isLoading 
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Current filter indicator
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Chip(
                      label: Text('Viewing: $_selectedFilter'),
                      backgroundColor: AppColors.primaryBlue.withOpacity(0.2),
                      labelStyle: TextStyle(color: AppColors.primaryBlue),
                    ),
                  ),
                  
                  // Account Settings
                  if (showAccount)
                    _buildSettingsSection(
                      'Account Settings',
                      [
                        _buildSettingItem(
                          icon: Icons.person,
                          title: 'Profile Information',
                          subtitle: 'Update your personal details',
                          trailing: const Icon(Icons.chevron_right),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.lock,
                          title: 'Security',
                          subtitle: 'Change password & security options',
                          trailing: const Icon(Icons.chevron_right),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.language,
                          title: 'Language',
                          trailing: DropdownButton<String>(
                            value: _selectedLanguage,
                            underline: Container(),
                            icon: const Icon(Icons.arrow_drop_down),
                            onChanged: (String? newValue) {
                              if (newValue != null) {
                                setState(() {
                                  _selectedLanguage = newValue;
                                });
                              }
                            },
                            items: _languages.map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  
                  // Appearance Settings
                  if (showAppearance)
                    _buildSettingsSection(
                      'Appearance',
                      [
                        _buildSettingItem(
                          icon: Icons.dark_mode,
                          title: 'Dark Mode',
                          trailing: Switch(
                            value: _darkMode,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _darkMode = value;
                                if (value) {
                                  _useSystemTheme = false;
                                }
                                // In a real app, this would call the themeProvider
                                // themeProvider.setDarkMode(value);
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.settings_system_daydream,
                          title: 'Use System Theme',
                          trailing: Switch(
                            value: _useSystemTheme,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _useSystemTheme = value;
                                if (value) {
                                  // System theme takes precedence
                                  _darkMode = false;
                                }
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.text_fields,
                          title: 'Text Size',
                          trailing: SegmentedButton<double>(
                            segments: const [
                              ButtonSegment(
                                value: 0.8,
                                label: Text('Small'),
                              ),
                              ButtonSegment(
                                value: 1.0,
                                label: Text('Medium'),
                              ),
                              ButtonSegment(
                                value: 1.2,
                                label: Text('Large'),
                              ),
                            ],
                            selected: {_textSize},
                            onSelectionChanged: (Set<double> newSelection) {
                              setState(() {
                                _textSize = newSelection.first;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    
                  // Notification Settings
                  if (showNotifications)
                    _buildSettingsSection(
                      'Notifications',
                      [
                        _buildSettingItem(
                          icon: Icons.email,
                          title: 'Email Notifications',
                          subtitle: 'Receive updates via email',
                          trailing: Switch(
                            value: _emailNotifications,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _emailNotifications = value;
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.notifications,
                          title: 'Push Notifications',
                          subtitle: 'Receive alerts on your device',
                          trailing: Switch(
                            value: _pushNotifications,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _pushNotifications = value;
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.task,
                          title: 'Task Reminders',
                          trailing: Switch(
                            value: _taskReminders,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _taskReminders = value;
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.inventory,
                          title: 'Inventory Alerts',
                          trailing: Switch(
                            value: _inventoryAlerts,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _inventoryAlerts = value;
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.calendar_today,
                          title: 'Project Updates',
                          trailing: Switch(
                            value: _projectUpdates,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _projectUpdates = value;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  
                  // Integration Settings
                  if (showIntegrations)
                    _buildSettingsSection(
                      'Integrations & Backup',
                      [
                        _buildSettingItem(
                          icon: Icons.business,
                          title: 'ERP Integration',
                          subtitle: 'Sync with enterprise systems',
                          trailing: Switch(
                            value: _syncWithERP,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _syncWithERP = value;
                              });
                            },
                          ),
                        ),
                        const Divider(height: 1),
                        _buildSettingItem(
                          icon: Icons.backup,
                          title: 'Cloud Backup',
                          subtitle: 'Automatically backup your data',
                          trailing: Switch(
                            value: _enableCloudBackup,
                            activeColor: AppColors.primaryBlue,
                            onChanged: (value) {
                              setState(() {
                                _enableCloudBackup = value;
                              });
                            },
                          ),
                        ),
                        if (_enableCloudBackup) ...[
                          const Divider(height: 1),
                          _buildSettingItem(
                            icon: Icons.update,
                            title: 'Backup Frequency',  // Fixed text label
                            trailing: SegmentedButton<int>(
                              segments: const [
                                ButtonSegment(
                                  value: 0,
                                  label: Text('Daily'),
                                ),
                                ButtonSegment(
                                  value: 1,
                                  label: Text('Weekly'),
                                ),
                                ButtonSegment(
                                  value: 2,
                                  label: Text('Monthly'),
                                ),
                              ],
                              selected: {_backupFrequency},
                              onSelectionChanged: (Set<int> newSelection) {
                                setState(() {
                                  _backupFrequency = newSelection.first;
                                });
                              },
                            ),
                          ),
                        ],
                      ],
                    ),
                ],
              ),
            ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed: _saveSettings,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBlue,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: _isLoading
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              : const Text('SAVE SETTINGS'),
        ),
      ),
    );
  }
}