import 'package:flutter/material.dart';
import '../../../core/navigation/route_paths.dart';
import '../../widgets/common/app_drawer.dart';
import '../../../data/models/user_model.dart';
import '../../../data/providers/auth_provider.dart';
import 'package:provider/provider.dart';

// Define an enum for user roles if not already defined elsewhere
enum UserRole { worker, accountant, manager, admin, developer }

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  /// Helper method to convert string role to UserRole enum
  UserRole _mapStringToUserRole(String role) {
    switch (role.toLowerCase()) {
      case 'worker':
        return UserRole.worker;
      case 'accountant':
        return UserRole.accountant;
      case 'manager':
        return UserRole.manager;
      case 'admin':
        return UserRole.admin;
      case 'developer':
        return UserRole.developer;
      default:
        return UserRole.worker; // Default case
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    
    // Get user role and handle potential null or string-based roles
    UserRole userRole;
    if (authProvider.currentUser?.role != null) {
      // If role is already a UserRole enum
      if (authProvider.currentUser!.role is UserRole) {
        userRole = authProvider.currentUser!.role as UserRole;
      } else {
        // If role is a string, convert it to UserRole enum
        userRole = _mapStringToUserRole(authProvider.currentUser!.role.toString());
      }
    } else {
      // Default to worker if no role is found
      userRole = UserRole.worker;
    }
    
    final String username = authProvider.currentUser?.name ?? 'User';
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // Show notifications
            },
          ),
        ],
      ),
      drawer: const AppDrawer(currentRoute: RoutePaths.dashboard),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Section - Shown to all users
            _buildWelcomePanel(context, username, userRole),
            const SizedBox(height: 24),
            
            // Quick Stats Section - Shown to Accountant, Manager, Admin, Developer, Inventory
            if (userRole == UserRole.accountant || 
                userRole == UserRole.manager || 
                userRole == UserRole.admin || 
                userRole == UserRole.developer)
              _buildQuickStatsSection(context, userRole),
            
            // Accountant-specific section - Only shown to Accountant
            if (userRole == UserRole.accountant)
              _buildAccountantSection(context),
            
            // Recent Projects Section - Shown to Manager, Admin, Developer
            if (userRole == UserRole.manager || 
                userRole == UserRole.admin || 
                userRole == UserRole.developer) ...[
              _buildRecentProjectsSection(context),
              const SizedBox(height: 24),
            ],
            
            // Today's Tasks Section - Shown to Worker, Manager, Admin, Developer
            if (userRole == UserRole.worker || 
                userRole == UserRole.manager || 
                userRole == UserRole.admin || 
                userRole == UserRole.developer)
              _buildTodaysTasksSection(context),
          ],
        ),
      ),
      // Only show FAB for Manager, Admin, and Developer roles
      floatingActionButton: (userRole == UserRole.manager || 
                            userRole == UserRole.admin || 
                            userRole == UserRole.developer)
          ? FloatingActionButton(
              onPressed: () {
                // Navigate to task creation screen
                // TODO: Implement task creation navigation
              },
              tooltip: 'Create Task',
              child: const Icon(Icons.add),
            )
          : null, // Hide FAB for other roles
    );
  }

  Widget _buildWelcomePanel(BuildContext context, String username, UserRole userRole) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 28,
              child: Icon(Icons.person, size: 32),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome, $username',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Tuesday, February 25, 2025',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                userRole.name.toUpperCase(),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickStatsSection(BuildContext context, UserRole userRole) {
    // Define which stat cards to show based on user role
    List<Widget> statCards = [];
    
    // Active Projects stat - shown to all roles that see Quick Stats
    statCards.add(
      _buildStatsCard(
        context,
        Icons.engineering,
        'Active Projects',
        '7',
        Colors.blue,
      ),
    );
    
    // Pending Tasks stat - not shown to accountant role
    if (userRole != UserRole.accountant) {
      statCards.add(
        _buildStatsCard(
          context,
          Icons.task,
          'Pending Tasks',
          '12',
          Colors.orange,
        ),
      );
    }
    
    // Low Inventory stat - shown to all roles that see Quick Stats
    statCards.add(
      _buildStatsCard(
        context,
        Icons.warning_amber,
        'Low Inventory',
        '3 items',
        Colors.red,
      ),
    );
    
    // Team Members stat - not shown to accountant role
    if (userRole != UserRole.accountant) {
      statCards.add(
        _buildStatsCard(
          context,
          Icons.people,
          'Team Members',
          '28',
          Colors.green,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Stats',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: statCards,
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildAccountantSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Financial Summary',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Monthly expenses summary
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Monthly Expenses',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    Text(
                      '₹ 24,75,000',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // Budget utilization
                Text(
                  'Budget Utilization',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: LinearProgressIndicator(
                        value: 0.68,
                        backgroundColor: Theme.of(context).colorScheme.surface,
                        color: Colors.amber,
                        minHeight: 10,
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '68%',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Pending approvals
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Pending Approvals'),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        '5',
                        style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Outstanding payments
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Outstanding Payments'),
                    Text(
                      '₹ 11,25,000',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildRecentProjectsSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Projects',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 16),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 3,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            return _buildProjectCard(context, index);
          },
        ),
      ],
    );
  }

  Widget _buildTodaysTasksSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Today\'s Tasks',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 16),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 4,
          separatorBuilder: (context, index) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            return _buildTaskCard(context, index);
          },
        ),
      ],
    );
  }

  Widget _buildStatsCard(
    BuildContext context,
    IconData icon,
    String title,
    String value,
    Color color,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 40,
              color: color,
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProjectCard(BuildContext context, int index) {
    // Dummy project data
    final List<Map<String, dynamic>> projects = [
      {
        'name': 'Kamptee-Kanhan Road',
        'progress': 0.75,
        'daysLeft': 45,
      },
      {
        'name': 'Nagpur Highway Extension',
        'progress': 0.35,
        'daysLeft': 120,
      },
      {
        'name': 'Saoner Bridge',
        'progress': 0.92,
        'daysLeft': 8,
      },
    ];
    
    final project = projects[index];
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    project['name'],
                    style: Theme.of(context).textTheme.titleMedium,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  '${project['daysLeft']} days left',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Progress bar
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Progress',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    Text(
                      '${(project['progress'] * 100).toInt()}%',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: project['progress'],
                  backgroundColor: Theme.of(context).colorScheme.surface,
                  color: _getProgressColor(project['progress']),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _getProgressColor(double progress) {
    if (progress < 0.3) return Colors.red;
    if (progress < 0.7) return Colors.orange;
    return Colors.green;
  }

  Widget _buildTaskCard(BuildContext context, int index) {
    // Dummy task data
    final List<Map<String, dynamic>> tasks = [
      {
        'title': 'Cement delivery inspection',
        'time': '10:00 AM',
        'isCompleted': false,
      },
      {
        'title': 'Quality check at Kamptee site',
        'time': '11:30 AM',
        'isCompleted': true,
      },
      {
        'title': 'Weekly team meeting',
        'time': '2:00 PM',
        'isCompleted': false,
      },
      {
        'title': 'Inventory reconciliation',
        'time': '4:30 PM',
        'isCompleted': false,
      },
    ];
    
    final task = tasks[index];
    
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: Icon(
          task['isCompleted'] ? Icons.check_circle : Icons.circle_outlined,
          color: task['isCompleted'] ? Colors.green : Colors.grey,
        ),
        title: Text(
          task['title'],
          style: TextStyle(
            decoration: task['isCompleted'] ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text(task['time']),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          // Navigate to task details
        },
      ),
    );
  }
}