import 'package:flutter/material.dart';
import '../../../core/navigation/route_paths.dart';
import '../../widgets/common/app_drawer.dart';

class ProjectsScreen extends StatelessWidget {
  const ProjectsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Dummy projects data
    final List<Map<String, dynamic>> projects = [
      {
        'id': 'PRJ001',
        'name': 'Kamptee-Kanhan Road',
        'location': 'Kamptee, Nagpur',
        'startDate': '2024-12-10',
        'endDate': '2025-04-15',
        'progress': 0.75,
        'status': 'In Progress',
      },
      {
        'id': 'PRJ002',
        'name': 'Nagpur Highway Extension',
        'location': 'Eastern Nagpur',
        'startDate': '2025-01-05',
        'endDate': '2025-06-30',
        'progress': 0.35,
        'status': 'In Progress',
      },
      {
        'id': 'PRJ003',
        'name': 'Saoner Bridge',
        'location': 'Saoner, Nagpur',
        'startDate': '2024-09-20',
        'endDate': '2025-03-05',
        'progress': 0.92,
        'status': 'Finishing',
      },
      {
        'id': 'PRJ004',
        'name': 'Wadi Industrial Road',
        'location': 'Wadi, Nagpur',
        'startDate': '2025-03-10',
        'endDate': '2025-08-25',
        'progress': 0.0,
        'status': 'Planned',
      },
      {
        'id': 'PRJ005',
        'name': 'Kalmeshwar Bypass',
        'location': 'Kalmeshwar, Nagpur',
        'startDate': '2024-07-15',
        'endDate': '2025-01-10',
        'progress': 1.0,
        'status': 'Completed',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Projects'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              // Show filter options
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // Show search
            },
          ),
        ],
      ),
      drawer: const AppDrawer(currentRoute: RoutePaths.projects),
      body: Column(
        children: [
          // Projects summary cards
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  _buildSummaryCard(
                    context,
                    'Total',
                    projects.length.toString(),
                    Icons.domain,
                    Theme.of(context).colorScheme.primary,
                  ),
                  _buildSummaryCard(
                    context,
                    'In Progress',
                    projects.where((p) => p['status'] == 'In Progress').length.toString(),
                    Icons.engineering,
                    Colors.orange,
                  ),
                  _buildSummaryCard(
                    context,
                    'Completed',
                    projects.where((p) => p['status'] == 'Completed').length.toString(),
                    Icons.check_circle,
                    Colors.green,
                  ),
                  _buildSummaryCard(
                    context,
                    'Planned',
                    projects.where((p) => p['status'] == 'Planned').length.toString(),
                    Icons.upcoming,
                    Colors.purple,
                  ),
                ],
              ),
            ),
          ),
          
          // Projects list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: projects.length,
              itemBuilder: (context, index) {
                final project = projects[index];
                
                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Project header
                        Row(
                          children: [
                            _buildStatusIndicator(project['status']),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                project['name'],
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.more_vert),
                              onPressed: () {
                                // Show project options
                              },
                              constraints: const BoxConstraints(),
                              padding: const EdgeInsets.all(8),
                            ),
                          ],
                        ),
                        
                        // Project details
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(
                            children: [
                              const Icon(Icons.location_on_outlined, size: 16, color: Colors.grey),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  project['location'],
                                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Colors.grey,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        // Project dates
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'Start Date',
                                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Colors.grey,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    project['startDate'],
                                    style: Theme.of(context).textTheme.bodyMedium,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'End Date',
                                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Colors.grey,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    project['endDate'],
                                    style: Theme.of(context).textTheme.bodyMedium,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        
                        // Progress bar
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Progress',
                                    style: Theme.of(context).textTheme.bodyMedium,
                                  ),
                                  Text(
                                    '${(project['progress'] * 100).toInt()}%',
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              LinearProgressIndicator(
                                value: project['progress'],
                                backgroundColor: Theme.of(context).colorScheme.surface,
                                color: _getProgressColor(project['progress']),
                              ),
                            ],
                          ),
                        ),
                        
                        // Action buttons
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton.icon(
                                icon: const Icon(Icons.task_alt),
                                label: const Text('Tasks'),
                                onPressed: () {
                                  // View tasks
                                },
                              ),
                              const SizedBox(width: 8),
                              TextButton.icon(
                                icon: const Icon(Icons.remove_red_eye),
                                label: const Text('Details'),
                                onPressed: () {
                                  // View details
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add new project
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildSummaryCard(
    BuildContext context,
    String title,
    String count,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 16),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Icon(icon, color: color, size: 20),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                count,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusIndicator(String status) {
    Color color;
    switch (status) {
      case 'In Progress':
        color = Colors.orange;
        break;
      case 'Completed':
        color = Colors.green;
        break;
      case 'Finishing':
        color = Colors.blue;
        break;
      case 'Planned':
        color = Colors.purple;
        break;
      default:
        color = Colors.grey;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Color _getProgressColor(double progress) {
    if (progress < 0.3) return Colors.red;
    if (progress < 0.7) return Colors.orange;
    return Colors.green;
  }
}