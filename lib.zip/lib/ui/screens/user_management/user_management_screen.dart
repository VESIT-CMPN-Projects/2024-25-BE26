import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:skg_mobile/ui/theme/app_colors.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../data/models/user_model.dart';
import '../../../core/navigation/route_paths.dart';
import '../../../mock_data/mock_users.dart';
import '../../widgets/common/app_drawer.dart';
import '../../widgets/common/loading_indicator.dart';

class UserManagementScreen extends StatefulWidget {
  const UserManagementScreen({Key? key}) : super(key: key);

  @override
  State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  // Current filter selection
  String _selectedFilter = 'All Users';
  final List<String> _filterOptions = [
    'All Users',
    'Admin',
    'Developer',
    'Manager',
    'Accountant',
    'Worker',
  ];

  // List to hold filtered users
  List<UserModel> _filteredUsers = [];
  
  // Loading state
  bool _isLoading = false;
  
  // Search query
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  
  // Controller for form fields
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _selectedRole = 'Worker';

  @override
  void initState() {
    super.initState();
    // Load users on startup
    _loadUsers();
    
    // Add listener to search controller
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text;
        _applyFilters();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // Load and filter users
  void _loadUsers() {
    setState(() {
      _isLoading = true;
      // Create a copy of mockUsers to avoid direct modification
      _filteredUsers = List.from(mockUsers);
      _applyFilters();
      _isLoading = false;
    });
  }

  // Apply filters based on role and search query
  void _applyFilters() {
    setState(() {
      if (_selectedFilter == 'All Users') {
        _filteredUsers = List.from(mockUsers);
      } else {
        _filteredUsers = mockUsers
            .where((user) => user.role == _selectedFilter)
            .toList();
      }

      // Apply search filter if query exists
      if (_searchQuery.isNotEmpty) {
        _filteredUsers = _filteredUsers
            .where((user) =>
                user.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                user.email.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                user.role.toLowerCase().contains(_searchQuery.toLowerCase()))
            .toList();
      }
    });
  }

  // Check if current user has admin privileges
  bool _hasAdminPrivileges(BuildContext context) {
    final currentUser = Provider.of<AuthProvider>(context, listen: false).currentUser;
    return currentUser != null && 
           (currentUser.role == 'Admin' || currentUser.role == 'Developer');
  }

  // Show add/edit user dialog
  Future<void> _showUserFormDialog(BuildContext context, {UserModel? user}) async {
    // Clear previous values
    _nameController.text = user?.name ?? '';
    _emailController.text = user?.email ?? '';
    _passwordController.text = user?.password ?? '';
    _selectedRole = user?.role ?? 'Worker';
    
    final isEditing = user != null;
    
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(isEditing ? 'Edit User' : 'Add New User'),
          content: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Full Name',
                      icon: Icon(Icons.person),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a name';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      icon: Icon(Icons.email),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter an email';
                      }
                      if (!value.contains('@')) {
                        return 'Please enter a valid email';
                      }
                      if (!isEditing && findUserByEmail(value) != null) {
                        return 'Email already exists';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _passwordController,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      icon: Icon(Icons.lock),
                    ),
                    obscureText: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a password';
                      }
                      if (value.length < 6) {
                        return 'Password must be at least 6 characters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedRole,
                    decoration: const InputDecoration(
                      labelText: 'Role',
                      icon: Icon(Icons.badge),
                    ),
                    items: ['Worker', 'Accountant', 'Manager', 'Admin', 'Developer']
                        .map((String role) {
                      return DropdownMenuItem<String>(
                        value: role,
                        child: Text(role),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedRole = newValue!;
                      });
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  if (isEditing) {
                    _updateUser(user!.id);
                  } else {
                    _addUser();
                  }
                  Navigator.of(context).pop();
                }
              },
              child: Text(isEditing ? 'Update' : 'Add'),
            ),
          ],
        );
      },
    );
  }

  // Add a new user
  void _addUser() {
    // Find the highest ID in the mockUsers list and increment by 1
    final int newId = mockUsers.fold(0, (max, user) => user.id > max ? user.id : max) + 1;
    
    // Create avatar URL based on name
    final String encodedName = _nameController.text.replaceAll(' ', '+');
    final String avatarUrl = 'https://ui-avatars.com/api/?name=$encodedName&background=4CAF50&color=fff';
    
    // Create new user
    final newUser = UserModel(
      id: newId,
      name: _nameController.text,
      email: _emailController.text,
      password: _passwordController.text,
      role: _selectedRole,
      avatarUrl: avatarUrl,
    );
    
    setState(() {
      // Add user to the list
      mockUsers.add(newUser);
      // Refresh filtered list
      _applyFilters();
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('User added successfully')),
    );
  }

  // Update an existing user
  void _updateUser(int userId) {
    setState(() {
      final index = mockUsers.indexWhere((user) => user.id == userId);
      if (index != -1) {
        // Create avatar URL based on name
        final String encodedName = _nameController.text.replaceAll(' ', '+');
        final String avatarUrl = mockUsers[index].avatarUrl;
        
        // Update user with new values
        mockUsers[index] = UserModel(
          id: userId,
          name: _nameController.text,
          email: _emailController.text,
          password: _passwordController.text,
          role: _selectedRole,
          avatarUrl: avatarUrl,
        );
        
        // Refresh filtered list
        _applyFilters();
      }
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('User updated successfully')),
    );
  }

  // Delete a user
  void _deleteUser(int userId) {
    // Show confirmation dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: const Text('Are you sure you want to delete this user? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              onPressed: () {
                setState(() {
                  // Remove user from list
                  mockUsers.removeWhere((user) => user.id == userId);
                  // Refresh filtered list
                  _applyFilters();
                });
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('User deleted successfully')),
                );
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  // Build the UI for a user tile
  Widget _buildUserTile(UserModel user) {
    // Get background color based on role for visual distinction
    Color getRoleColor(String role) {
      switch (role) {
        case 'Admin':
          return Colors.purple.withOpacity(0.2);
        case 'Developer':
          return Colors.red.withOpacity(0.2);
        case 'Manager':
          return Colors.green.withOpacity(0.2);
        case 'Accountant':
          return Colors.amber.withOpacity(0.2);
        case 'Worker':
        default:
          return Colors.blue.withOpacity(0.2);
      }
    }

    final bool hasAdminAccess = _hasAdminPrivileges(context);
    
    return Slidable(
      // Enable sliding actions only for admin/developer roles
      enabled: hasAdminAccess,
      // Action pane on the right side
      endActionPane: ActionPane(
        motion: const ScrollMotion(),
        extentRatio: 0.25,
        children: [
          // Edit action
          SlidableAction(
            onPressed: (_) => _showUserFormDialog(context, user: user),
            backgroundColor: AppColors.primaryBlue,
            foregroundColor: Colors.white,
            icon: Icons.edit,
            label: 'Edit',
          ),
          // Delete action
          SlidableAction(
            onPressed: (_) => _deleteUser(user.id),
            backgroundColor: Colors.red,
            foregroundColor: Colors.white,
            icon: Icons.delete,
            label: 'Delete',
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        tileColor: getRoleColor(user.role),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        leading: CircleAvatar(
          backgroundImage: NetworkImage(user.avatarUrl),
        ),
        title: Text(
          user.name,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(user.email),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: getRoleColor(user.role).withOpacity(0.7),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                user.role,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        trailing: hasAdminAccess
            ? const Icon(Icons.chevron_left, color: Colors.white60)
            : null,
        onTap: hasAdminAccess
            ? () => _showUserFormDialog(context, user: user)
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Get current user to check permissions
    final authProvider = Provider.of<AuthProvider>(context);
    final currentUser = authProvider.currentUser;
    final bool hasAdminAccess = _hasAdminPrivileges(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Management'),
        actions: [
          // Only show add user icon for admin/developer roles
          if (hasAdminAccess)
            IconButton(
              icon: const Icon(Icons.person_add),
              onPressed: () => _showUserFormDialog(context),
              tooltip: 'Add New User',
            ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            tooltip: 'Filter Users by Role',
            onSelected: (value) {
              setState(() {
                _selectedFilter = value;
                _applyFilters();
              });
            },
            itemBuilder: (BuildContext context) {
              return _filterOptions.map((String option) {
                return PopupMenuItem<String>(
                  value: option,
                  child: Row(
                    children: [
                      if (_selectedFilter == option)
                        const Icon(Icons.check, color: AppColors.primaryBlue)
                      else
                        const SizedBox(width: 24),
                      const SizedBox(width: 8),
                      Text(option),
                    ],
                  ),
                );
              }).toList();
            },
          ),
        ],
      ),
      drawer: const AppDrawer(currentRoute: RoutePaths.userManagement),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by name, email, or role',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                        },
                      )
                    : null,
              ),
            ),
          ),
          
          // Filter chips to show active filters
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                const Text(
                  'Showing: ',
                  style: TextStyle(color: Colors.white70),
                ),
                Chip(
                  label: Text(_selectedFilter),
                  backgroundColor: AppColors.primaryBlue.withOpacity(0.3),
                ),
                if (_searchQuery.isNotEmpty) ...[
                  const SizedBox(width: 8),
                  Chip(
                    label: Text('Search: "${_searchQuery}"'),
                    backgroundColor: AppColors.accentGold.withOpacity(0.3),
                    onDeleted: () {
                      _searchController.clear();
                    },
                  ),
                ],
              ],
            ),
          ),
          
          // User count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Row(
              children: [
                Text(
                  '${_filteredUsers.length} users found',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          
          // Loading indicator or user list
          Expanded(
            child: _isLoading
                ? const Center(child: LoadingIndicator())
                : _filteredUsers.isEmpty
                    ? const Center(
                        child: Text(
                          'No users found',
                          style: TextStyle(color: Colors.white70),
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _filteredUsers.length,
                        separatorBuilder: (context, index) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          return _buildUserTile(_filteredUsers[index]);
                        },
                      ),
          ),
        ],
      ),
      // FAB for adding users (only for admin/developer roles)
      floatingActionButton: hasAdminAccess
          ? FloatingActionButton(
              onPressed: () => _showUserFormDialog(context),
              tooltip: 'Add New User',
              child: const Icon(Icons.person_add),
            )
          : null,
    );
  }
}