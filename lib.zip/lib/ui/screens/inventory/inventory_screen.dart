import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/constants/color_constants.dart';
import '../../../core/navigation/route_paths.dart';
import '../../../data/models/inventory_model.dart';
import '../../../mock_data/mock_inventory.dart' as mock_data;
import '../../widgets/common/app_drawer.dart';
import '../../widgets/common/loading_indicator.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({Key? key}) : super(key: key);

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  // Filter and search state
  String _selectedCategory = 'All';
  String _searchQuery = '';
  bool _showLowStockOnly = false;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  // Inventory data
  late List<InventoryModel> _inventoryItems;
  
  // Define the material categories for filtering
  final List<String> _categories = ['All', 'Low Stock', 'Empty'];

  @override
  void initState() {
    super.initState();
    _loadInventoryData();
  }

  // Load inventory data with simulated network delay
  Future<void> _loadInventoryData() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Load data from mock
      setState(() {
        // Create a deep copy of the mock inventory to work with
        _inventoryItems = List.from(mock_data.mockInventory);
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = 'Failed to load inventory data: ${e.toString()}';
      });
    }
  }

  // Filter inventory items based on current filters and search
  List<InventoryModel> get _filteredInventory {
    return _inventoryItems.where((item) {
      // Apply category filter
      if (_selectedCategory == 'Low Stock' && !item.isLow) {
        return false;
      }
      
      // Apply Empty filter
      if (_selectedCategory == 'Empty' && item.quantity > 0) {
        return false;
      }
      
      // Apply search filter if search is not empty
      if (_searchQuery.isNotEmpty && 
          !item.materialName.toLowerCase().contains(_searchQuery.toLowerCase())) {
        return false;
      }
      
      return true;
    }).toList();
  }

  // Add a new inventory item (update mock data)
  void _addInventoryItem(InventoryModel newItem) {
    setState(() {
      // Update local state
      _inventoryItems.add(newItem);
      
      // Update mock data
      mock_data.mockInventory.add(newItem);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Inventory item added successfully')),
    );
  }

  // Update an existing inventory item (update mock data)
  void _updateInventoryItem(InventoryModel updatedItem) {
    setState(() {
      // Update local state
      final index = _inventoryItems.indexWhere((item) => item.id == updatedItem.id);
      if (index != -1) {
        _inventoryItems[index] = updatedItem;
      }
      
      // Update mock data
      final mockIndex = mock_data.mockInventory.indexWhere((item) => item.id == updatedItem.id);
      if (mockIndex != -1) {
        mock_data.mockInventory[mockIndex] = updatedItem;
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Inventory item updated successfully')),
    );
  }

  // Delete an inventory item (update mock data)
  void _deleteInventoryItem(int id) {
    setState(() {
      // Update local state
      _inventoryItems.removeWhere((item) => item.id == id);
      
      // Update mock data
      mock_data.mockInventory.removeWhere((item) => item.id == id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Inventory item deleted successfully')),
    );
  }

  // Show dialog to add or edit an inventory item
  Future<void> _showInventoryFormDialog(BuildContext context, {InventoryModel? item}) async {
    final isEditing = item != null;
    final TextEditingController nameController = TextEditingController(text: isEditing ? item.materialName : '');
    final TextEditingController quantityController = TextEditingController(text: isEditing ? item.quantity.toString() : '');
    final TextEditingController thresholdController = TextEditingController(text: isEditing ? item.alertThreshold.toString() : '');
    
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(isEditing ? 'Edit Inventory Item' : 'Add Inventory Item'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Material Name',
                    hintText: 'Enter material name',
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: quantityController,
                  decoration: const InputDecoration(
                    labelText: 'Quantity',
                    hintText: 'Enter current quantity',
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$')),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: thresholdController,
                  decoration: const InputDecoration(
                    labelText: 'Alert Threshold',
                    hintText: 'Enter minimum quantity',
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$')),
                  ],
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
            ElevatedButton(
              child: Text(isEditing ? 'Update' : 'Add'),
              onPressed: () {
                // Validate input
                if (nameController.text.isEmpty ||
                    quantityController.text.isEmpty ||
                    thresholdController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please fill in all fields')),
                  );
                  return;
                }

                final newItem = InventoryModel(
                  id: isEditing ? item.id : _getNextInventoryId(),
                  materialName: nameController.text,
                  quantity: double.parse(quantityController.text),
                  alertThreshold: double.parse(thresholdController.text),
                );

                if (isEditing) {
                  _updateInventoryItem(newItem);
                } else {
                  _addInventoryItem(newItem);
                }

                Navigator.of(dialogContext).pop();
              },
            ),
          ],
        );
      },
    );
  }

  // Generate next available ID for new inventory items
  int _getNextInventoryId() {
    if (_inventoryItems.isEmpty) return 1;
    return _inventoryItems.map((item) => item.id).reduce((value, element) => value > element ? value : element) + 1;
  }

  // Show confirmation dialog before deleting an item
  void _showDeleteConfirmationDialog(BuildContext context, InventoryModel item) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete "${item.materialName}"?'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ColorConstants.error,
              ),
              child: const Text('Delete'),
              onPressed: () {
                _deleteInventoryItem(item.id);
                Navigator.of(dialogContext).pop();
              },
            ),
          ],
        );
      },
    );
  }

  // Show detail view for an inventory item
  void _showDetailBottomSheet(BuildContext context, InventoryModel item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext bottomSheetContext) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      item.materialName,
                      style: Theme.of(context).textTheme.titleLarge,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(bottomSheetContext),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _buildDetailRow('Material ID', '#${item.id}'),
              _buildDetailRow('Current Quantity', item.quantity.toString()),
              _buildDetailRow('Alert Threshold', item.alertThreshold.toString()),
              _buildDetailRow(
                'Status', 
                item.quantity == 0 
                    ? 'Empty' 
                    : (item.isLow ? 'Low Stock' : 'In Stock')
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.edit),
                      label: const Text('Edit'),
                      onPressed: () {
                        Navigator.pop(bottomSheetContext);
                        _showInventoryFormDialog(context, item: item);
                      },
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.delete),
                      label: const Text('Delete'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: ColorConstants.error,
                      ),
                      onPressed: () {
                        Navigator.pop(bottomSheetContext);
                        _showDeleteConfirmationDialog(context, item);
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                color: ColorConstants.textSecondary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: ColorConstants.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventory'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                context: context,
                delegate: InventorySearchDelegate(
                  items: _inventoryItems,
                  onItemSelected: (item) {
                    _showDetailBottomSheet(context, item);
                  },
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadInventoryData,
          ),
        ],
      ),
      drawer: const AppDrawer(currentRoute: RoutePaths.inventory),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showInventoryFormDialog(context),
        tooltip: 'Add Inventory Item',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: LoadingIndicator());
    }

    if (_hasError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: ColorConstants.error),
            const SizedBox(height: 16),
            Text(_errorMessage),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
              onPressed: _loadInventoryData,
            ),
          ],
        ),
      );
    }

    if (_inventoryItems.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inventory_2_outlined, size: 64, color: ColorConstants.disabled),
            SizedBox(height: 16),
            Text('No inventory items found'),
          ],
        ),
      );
    }

    return Column(
      children: [
        _buildFilters(),
        _buildSummaryCards(),
        Expanded(
          child: _filteredInventory.isEmpty
              ? const Center(
                  child: Text('No items match the current filters'),
                )
              : _buildInventoryList(),
        ),
      ],
    );
  }

  Widget _buildFilters() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    hintText: 'Search inventory items...',
                    prefixIcon: Icon(Icons.search),
                    contentPadding: EdgeInsets.symmetric(vertical: 0),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: Icon(
                  _showLowStockOnly ? Icons.filter_list : Icons.filter_list_outlined,
                  color: _showLowStockOnly ? ColorConstants.warning : null,
                ),
                onPressed: () {
                  setState(() {
                    _showLowStockOnly = !_showLowStockOnly;
                    _selectedCategory = _showLowStockOnly ? 'Low Stock' : 'All';
                  });
                },
                tooltip: 'Show Low Stock Items',
              ),
            ],
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final category in _categories)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(category),
                      selected: _selectedCategory == category,
                      onSelected: (selected) {
                        if (selected) {
                          setState(() {
                            _selectedCategory = category;
                            _showLowStockOnly = category == 'Low Stock';
                          });
                        }
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCards() {
    final totalItems = _inventoryItems.length;
    final lowStockItems = _inventoryItems.where((item) => item.isLow && item.quantity > 0).length;
    final emptyItems = _inventoryItems.where((item) => item.quantity == 0).length;
    
    return Container(
      height: 110, // Fixed height for the summary cards
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildSummaryCard(
              title: 'Total Items',
              count: totalItems,
              icon: Icons.inventory_2,
              color: ColorConstants.primary,
            ),
            const SizedBox(width: 8),
            _buildSummaryCard(
              title: 'Low Stock',
              count: lowStockItems,
              icon: Icons.warning_amber_rounded,
              color: ColorConstants.warning,
            ),
            const SizedBox(width: 8),
            _buildSummaryCard(
              title: 'Empty',
              count: emptyItems,
              icon: Icons.remove_shopping_cart,
              color: ColorConstants.error,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard({
    required String title,
    required int count,
    required IconData icon,
    required Color color,
  }) {
    return SizedBox(
      width: 150, // Fixed width for each card
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: color, size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      title,
                      style: TextStyle(
                        color: ColorConstants.textSecondary,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                count.toString(),
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInventoryList() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: _filteredInventory.length,
      itemBuilder: (context, index) {
        final item = _filteredInventory[index];
        final bool isEmpty = item.quantity == 0;
        
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: isEmpty 
                  ? ColorConstants.error 
                  : (item.isLow ? ColorConstants.warning : ColorConstants.primary),
              child: Icon(
                isEmpty 
                    ? Icons.remove_shopping_cart
                    : (item.isLow ? Icons.warning_amber_rounded : Icons.inventory_2),
                color: ColorConstants.textPrimary,
                size: 20,
              ),
            ),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    item.materialName,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isEmpty 
                        ? ColorConstants.error.withOpacity(0.2)
                        : (item.isLow ? ColorConstants.warning.withOpacity(0.2) : ColorConstants.success.withOpacity(0.2)),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    isEmpty 
                        ? 'Empty'
                        : (item.isLow ? 'Low Stock' : 'In Stock'),
                    style: TextStyle(
                      color: isEmpty 
                          ? ColorConstants.error
                          : (item.isLow ? ColorConstants.warning : ColorConstants.success),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Text(
                        'Quantity: ${item.quantity}', 
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'Min: ${item.alertThreshold}', 
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            trailing: SizedBox(
              width: 96, // Fixed width for the trailing actions
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit_outlined, size: 20),
                    onPressed: () => _showInventoryFormDialog(context, item: item),
                    tooltip: 'Edit item',
                    constraints: const BoxConstraints(
                      minWidth: 40,
                      minHeight: 40,
                    ),
                    padding: EdgeInsets.zero,
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, size: 20),
                    onPressed: () => _showDeleteConfirmationDialog(context, item),
                    tooltip: 'Delete item',
                    constraints: const BoxConstraints(
                      minWidth: 40,
                      minHeight: 40,
                    ),
                    padding: EdgeInsets.zero,
                  ),
                ],
              ),
            ),
            onTap: () => _showDetailBottomSheet(context, item),
          ),
        );
      },
    );
  }
}

// Custom search delegate for inventory items
class InventorySearchDelegate extends SearchDelegate<InventoryModel?> {
  final List<InventoryModel> items;
  final Function(InventoryModel) onItemSelected;

  InventorySearchDelegate({required this.items, required this.onItemSelected});

  @override
  ThemeData appBarTheme(BuildContext context) {
    final theme = Theme.of(context);
    return theme.copyWith(
      appBarTheme: AppBarTheme(
        backgroundColor: theme.appBarTheme.backgroundColor,
        foregroundColor: theme.appBarTheme.foregroundColor,
      ),
      inputDecorationTheme: InputDecorationTheme(
        // Add padding to the search field
        contentPadding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
        // You can also add other styling properties
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: theme.colorScheme.surface,
        // Preserve any other properties from the existing theme if needed
        hintStyle: theme.inputDecorationTheme.hintStyle,
      ),
    );
  }

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return _buildSearchResults(context);
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return _buildSearchResults(context);
  }

  Widget _buildSearchResults(BuildContext context) {
    if (query.isEmpty) {
      return const Center(
        child: Text('Enter a search term to find inventory items'),
      );
    }

    final results = items.where(
      (item) => item.materialName.toLowerCase().contains(query.toLowerCase())
    ).toList();

    if (results.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_off, size: 64, color: ColorConstants.disabled),
            const SizedBox(height: 16),
            Text('No results found for "$query"'),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (context, index) {
        final item = results[index];
        final bool isEmpty = item.quantity == 0;
        
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: isEmpty 
                ? ColorConstants.error 
                : (item.isLow ? ColorConstants.warning : ColorConstants.primary),
            child: Icon(
              isEmpty 
                  ? Icons.remove_shopping_cart
                  : (item.isLow ? Icons.warning_amber_rounded : Icons.inventory_2),
              color: ColorConstants.textPrimary,
              size: 20,
            ),
          ),
          title: Text(item.materialName),
          subtitle: Text('Quantity: ${item.quantity}'),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isEmpty 
                  ? ColorConstants.error.withOpacity(0.2)
                  : (item.isLow ? ColorConstants.warning.withOpacity(0.2) : ColorConstants.success.withOpacity(0.2)),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              isEmpty 
                  ? 'Empty'
                  : (item.isLow ? 'Low Stock' : 'In Stock'),
              style: TextStyle(
                color: isEmpty 
                    ? ColorConstants.error
                    : (item.isLow ? ColorConstants.warning : ColorConstants.success),
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          onTap: () {
            close(context, item);
            onItemSelected(item);
          },
        );
      },
    );
  }
}