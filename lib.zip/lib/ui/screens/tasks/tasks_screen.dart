import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:skg_mobile/core/navigation/route_paths.dart';
import 'package:skg_mobile/ui/widgets/common/app_drawer.dart';
import 'package:skg_mobile/data/providers/auth_provider.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_constants.dart';
import '../../../data/models/task_model.dart';
import '../../../data/repositories/task_repository.dart';
import '../../theme/app_colors.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({Key? key}) : super(key: key);

  @override
  State<TasksScreen> createState() => _TasksScreenState();
} 

class _TasksScreenState extends State<TasksScreen> {
  late List<TaskModel> _allTasks;
  late List<TaskModel> _filteredTasks;
  late DateTime _selectedDay;
  late DateTime _focusedDay;
  late CalendarFormat _calendarFormat;
  bool _isLoading = true;
  String _selectedFilter = 'All';
  final List<String> _filterOptions = ['All', 'Pending', 'In Progress', 'Completed', 'Delayed'];
  
  // Create an instance of the task repository
  final TaskRepository _taskRepository = TaskRepository();

  @override
  void initState() {
    super.initState();
    _selectedDay = DateTime.now();
    _focusedDay = DateTime.now();
    _calendarFormat = CalendarFormat.week;
    _loadTasks();
  }

  void _loadTasks() async {
    // Simulate API call
    await Future.delayed(const Duration(milliseconds: 800));
    
    setState(() {
      // Use the repository to get all tasks
      _allTasks = _taskRepository.getAllTasks();
      _applyFilters();
      _isLoading = false;
    });
  }

  void _applyFilters() {
    if (_selectedFilter == 'All') {
      _filteredTasks = List.from(_allTasks);
    } else {
      _filteredTasks = _allTasks.where((task) => task.status == _selectedFilter).toList();
    }
    
    // Further filter by selected date if not in list view
    if (_calendarFormat != CalendarFormat.month) {
      _filteredTasks = _filteredTasks.where((task) {
        return task.deadline.year == _selectedDay.year &&
               task.deadline.month == _selectedDay.month &&
               task.deadline.day == _selectedDay.day;
      }).toList();
    }
  }

  Future<void> _refreshTasks() async {
    setState(() {
      _isLoading = true;
    });
    _loadTasks();
    return Future.value();
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _selectedDay = selectedDay;
      _focusedDay = focusedDay;
      _applyFilters();
    });
  }

  // Get event count for a given day to show indicators on calendar
  List<TaskModel> _getEventsForDay(DateTime day) {
    return _allTasks.where((task) => 
      task.deadline.year == day.year &&
      task.deadline.month == day.month &&
      task.deadline.day == day.day).toList();
  }

  void _toggleCalendarFormat() {
    setState(() {
      _calendarFormat = _calendarFormat == CalendarFormat.week
          ? CalendarFormat.month
          : CalendarFormat.week;
      _applyFilters();
    });
  }

  void _createNewTask() {
    TaskModel newTask = TaskModel(
      id: 0, // Temporary ID, will be set by repository
      projectId: 1, // Default project ID
      title: '',
      description: '',
      deadline: _selectedDay,
      status: 'Pending',
    );
    
    _showTaskDialog(newTask, isNew: true);
  }

  void _deleteTask(TaskModel task) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.backgroundMedium,
          title: const Text('Delete Task'),
          content: Text('Are you sure you want to delete "${task.title}"?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.error,
              ),
              onPressed: () {
                // Use repository to delete the task
                final success = _taskRepository.deleteTask(task.id);
                
                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Task deleted successfully'),
                      backgroundColor: AppColors.success,
                    ),
                  );
                  
                  setState(() {
                    _loadTasks(); // Reload tasks to reflect changes
                  });
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Failed to delete task'),
                      backgroundColor: AppColors.error,
                    ),
                  );
                }
                
                Navigator.of(context).pop();
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  void _showTaskDialog(TaskModel task, {bool isNew = false}) {
    final _formKey = GlobalKey<FormState>();
    String _title = task.title;
    String _description = task.description;
    DateTime _deadline = task.deadline;
    String _status = task.status;
    int _projectId = task.projectId;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.backgroundMedium,
          title: Text(isNew ? 'Create New Task' : 'Edit Task'),
          content: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    initialValue: _title,
                    decoration: const InputDecoration(
                      labelText: 'Title',
                      hintText: 'Enter task title',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a title';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _title = value;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    initialValue: _description,
                    decoration: const InputDecoration(
                      labelText: 'Description',
                      hintText: 'Enter task description',
                    ),
                    maxLines: 3,
                    onChanged: (value) {
                      _description = value;
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Deadline: ${DateFormat('MMM dd, yyyy').format(_deadline)}',
                          style: const TextStyle(color: AppColors.textSecondary),
                        ),
                      ),
                      TextButton(
                        onPressed: () async {
                          // Get today's date to ensure we don't allow past dates
                          final DateTime now = DateTime.now();
                          // Use the max of current date or deadline to prevent initialDate being before firstDate
                          final DateTime initialPickerDate = 
                              _deadline.isBefore(now) ? now : _deadline;
                          
                          final DateTime? picked = await showDatePicker(
                            context: context,
                            initialDate: initialPickerDate,
                            firstDate: now,
                            lastDate: DateTime(2030),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(
                                  colorScheme: const ColorScheme.dark(
                                    primary: AppColors.primaryBlue,
                                    onPrimary: AppColors.textPrimary,
                                    surface: AppColors.backgroundMedium,
                                    onSurface: AppColors.textPrimary,
                                  ),
                                ),
                                child: child!,
                              );
                            },
                          );
                          if (picked != null) {
                            setState(() {
                              _deadline = picked;
                            });
                          }
                        },
                        child: const Text('Change'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _status,
                    decoration: const InputDecoration(
                      labelText: 'Status',
                    ),
                    items: ['Pending', 'In Progress', 'Completed', 'Delayed']
                        .map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (newValue) {
                      _status = newValue!;
                    },
                  ),
                  const SizedBox(height: 16),
                  // This would ideally fetch projects dynamically
                  DropdownButtonFormField<int>(
                    value: _projectId,
                    decoration: const InputDecoration(
                      labelText: 'Project',
                    ),
                    isExpanded: true, // Add this to make the dropdown use all available width
                    items: const [
                      DropdownMenuItem<int>(
                        value: 1,
                        child: Text('Kamptee Highway Extension', overflow: TextOverflow.ellipsis),
                      ),
                      DropdownMenuItem<int>(
                        value: 2,
                        child: Text('Nagpur City Flyover', overflow: TextOverflow.ellipsis),
                      ),
                      DropdownMenuItem<int>(
                        value: 3,
                        child: Text('Koradi Road Widening', overflow: TextOverflow.ellipsis),
                      ),
                      DropdownMenuItem<int>(
                        value: 4,
                        child: Text('Ramtek Temple Access Road', overflow: TextOverflow.ellipsis),
                      ),
                      DropdownMenuItem<int>(
                        value: 5,
                        child: Text('Butibori Industrial Area', overflow: TextOverflow.ellipsis),
                      ),
                    ],
                    onChanged: (newValue) {
                      _projectId = newValue!;
                    },
                  ),
                
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  if (isNew) {
                    // Create new task using repository
                    TaskModel newTask = TaskModel(
                      id: 0, // Will be set by repository
                      projectId: _projectId,
                      title: _title,
                      description: _description,
                      deadline: _deadline,
                      status: _status,
                    );
                    
                    _taskRepository.createTask(newTask);
                    
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Task created successfully'),
                        backgroundColor: AppColors.success,
                      ),
                    );
                  } else {
                    // Update existing task using repository
                    TaskModel updatedTask = TaskModel(
                      id: task.id,
                      projectId: _projectId,
                      title: _title,
                      description: _description,
                      deadline: _deadline,
                      status: _status,
                    );
                    
                    final success = _taskRepository.updateTask(updatedTask);
                    
                    if (success) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Task updated successfully'),
                          backgroundColor: AppColors.success,
                        ),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Failed to update task'),
                          backgroundColor: AppColors.error,
                        ),
                      );
                    }
                  }
                  
                  // Reload tasks to reflect changes
                  setState(() {
                    _loadTasks();
                  });
                  
                  Navigator.of(context).pop();
                }
              },
              child: Text(isNew ? 'Create' : 'Save'),
            ),
          ],
        );
      },
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return AppColors.success;
      case 'In Progress':
        return AppColors.info;
      case 'Delayed':
        return AppColors.error;
      case 'Pending':
        return AppColors.warning;
      default:
        return AppColors.textSecondary;
    }
  }

  Widget _buildTaskList() {
    if (_filteredTasks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.task_alt,
              size: 80,
              color: Colors.white24,
            ),
            const SizedBox(height: 16),
            Text(
              _calendarFormat == CalendarFormat.month
                  ? 'No tasks found with the selected filter'
                  : 'No tasks scheduled for ${DateFormat.yMMMd().format(_selectedDay)}',
              style: const TextStyle(color: AppColors.textSecondary),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _createNewTask,
              child: const Text('Create a New Task'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: _filteredTasks.length,
      padding: const EdgeInsets.only(bottom: 80), // Space for FAB
      itemBuilder: (context, index) {
        final task = _filteredTasks[index];
        final isOverdue = task.deadline.isBefore(DateTime.now()) && 
                          task.status != 'Completed';
                          
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          elevation: 2,
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    task.title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      decoration: task.status == 'Completed'
                          ? TextDecoration.lineThrough
                          : null,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor(task.status).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(
                      color: _getStatusColor(task.status),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    task.status,
                    style: TextStyle(
                      fontSize: 12,
                      color: _getStatusColor(task.status),
                    ),
                  ),
                ),
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                Text(
                  task.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      size: 16,
                      color: isOverdue ? AppColors.error : AppColors.textSecondary,
                    ),
                    const SizedBox(width: 4),
                    Flexible(  // Added Flexible here to allow text to shrink if needed
                      child: Text(
                        DateFormat.yMMMd().format(task.deadline),
                        style: TextStyle(
                          color: isOverdue ? AppColors.error : AppColors.textSecondary,
                          fontWeight: isOverdue ? FontWeight.bold : FontWeight.normal,
                        ),
                        overflow: TextOverflow.ellipsis,  // Add this to prevent text overflow
                      ),
                    ),
                    if (isOverdue) ...[
                      const SizedBox(width: 4),
                      Text(
                        '(Overdue)',
                        style: TextStyle(
                          color: AppColors.error,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                    const Spacer(),
                    // Create a row for task action buttons to better organize them
                    Row(
                      mainAxisSize: MainAxisSize.min,  // Take minimum space needed
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, size: 20),
                          color: AppColors.primaryBlue,
                          onPressed: () => _showTaskDialog(task),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                          tooltip: 'Edit Task',
                        ),
                        const SizedBox(width: 16),
                        IconButton(
                          icon: task.status == 'Completed'
                              ? const Icon(Icons.replay, size: 20)
                              : const Icon(Icons.check_circle, size: 20),
                          color: task.status == 'Completed'
                              ? AppColors.warning
                              : AppColors.success,
                          onPressed: () {
                            // Use repository to update task status
                            final newStatus = task.status == 'Completed' ? 'Pending' : 'Completed';
                            final success = _taskRepository.updateTaskStatus(task.id, newStatus);
                            
                            if (success) {
                              setState(() {
                                _loadTasks(); // Reload tasks to reflect changes
                              });
                              
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    task.status == 'Completed'
                                        ? 'Task marked as pending'
                                        : 'Task marked as completed'
                                  ),
                                  backgroundColor: task.status == 'Completed'
                                      ? AppColors.warning
                                      : AppColors.success,
                                  duration: const Duration(seconds: 2),
                                ),
                              );
                            }
                          },
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                          tooltip: task.status == 'Completed'
                              ? 'Mark as Pending'
                              : 'Mark as Completed',
                        ),
                        const SizedBox(width: 16),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, size: 20),
                          color: AppColors.error,
                          onPressed: () => _deleteTask(task),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                          tooltip: 'Delete Task',
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            onTap: () => _showTaskDialog(task),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final userRole = auth.currentUser?.role ?? 'Worker';
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasks'),
        actions: [
          IconButton(
            icon: Icon(_calendarFormat == CalendarFormat.week
                ? Icons.calendar_view_month
                : Icons.calendar_view_week),
            onPressed: _toggleCalendarFormat,
            tooltip: _calendarFormat == CalendarFormat.week
                ? 'Switch to Month View'
                : 'Switch to Week View',
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            tooltip: 'Filter Tasks',
            onSelected: (value) {
              setState(() {
                _selectedFilter = value;
                _applyFilters();
              });
            },
            itemBuilder: (BuildContext context) {
              return _filterOptions.map((String option) {
                return PopupMenuItem<String>(
                  value: option,
                  child: Row(
                    children: [
                      if (_selectedFilter == option)
                        const Icon(Icons.check, color: AppColors.primaryBlue)
                      else
                        const SizedBox(width: 24),
                      const SizedBox(width: 8),
                      Text(option),
                    ],
                  ),
                );
              }).toList();
            },
          ),
        ],
      ),
      drawer: const AppDrawer(currentRoute: RoutePaths.tasks),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _refreshTasks,
              child: Column(
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      color: AppColors.backgroundMedium,
                    ),
                    child: TableCalendar(
                      firstDay: DateTime.utc(2023, 1, 1),
                      lastDay: DateTime.utc(2030, 12, 31),
                      focusedDay: _focusedDay,
                      calendarFormat: _calendarFormat,
                      eventLoader: _getEventsForDay,
                      selectedDayPredicate: (day) {
                        return isSameDay(_selectedDay, day);
                      },
                      onDaySelected: _onDaySelected,
                      onFormatChanged: (format) {
                        setState(() {
                          _calendarFormat = format;
                          _applyFilters();
                        });
                      },
                      onPageChanged: (focusedDay) {
                        _focusedDay = focusedDay;
                      },
                      headerStyle: const HeaderStyle(
                        titleCentered: true,
                        formatButtonVisible: false,
                        leftChevronIcon: Icon(Icons.chevron_left, color: AppColors.textPrimary),
                        rightChevronIcon: Icon(Icons.chevron_right, color: AppColors.textPrimary),
                        titleTextStyle: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      calendarStyle: CalendarStyle(
                        defaultTextStyle: const TextStyle(color: AppColors.textPrimary),
                        weekendTextStyle: const TextStyle(color: AppColors.textSecondary),
                        outsideTextStyle: const TextStyle(color: AppColors.textDisabled),
                        selectedDecoration: const BoxDecoration(
                          color: AppColors.primaryBlue,
                          shape: BoxShape.circle,
                        ),
                        todayDecoration: BoxDecoration(
                          color: AppColors.primaryBlue.withOpacity(0.3),
                          shape: BoxShape.circle,
                        ),
                        markersMaxCount: 3,
                        markersAlignment: Alignment.bottomCenter,
                        markerDecoration: const BoxDecoration(
                          color: AppColors.accentTeal,
                          shape: BoxShape.circle,
                        ),
                      ),
                      daysOfWeekStyle: const DaysOfWeekStyle(
                        weekdayStyle: TextStyle(color: AppColors.textSecondary),
                        weekendStyle: TextStyle(color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                  const Divider(height: 0),
                  Expanded(child: _buildTaskList()),
                ],
              ),
            ),
      floatingActionButton: userRole != 'Worker' 
          ? FloatingActionButton(
              onPressed: _createNewTask,
              tooltip: 'Add new task',
              child: const Icon(Icons.add),
            )
          : null, // Workers cannot create tasks
    );
  }
}