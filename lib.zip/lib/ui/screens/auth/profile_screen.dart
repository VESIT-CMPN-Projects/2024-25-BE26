import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:skg_mobile/core/navigation/route_paths.dart';
import 'package:skg_mobile/ui/widgets/common/app_drawer.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/color_constants.dart';
import '../../../data/models/user_model.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../core/utils/validators.dart';
import '../../widgets/common/loading_indicator.dart';
import '../../widgets/common/custom_app_bar.dart';
import '../../theme/app_colors.dart';

// Define an enum for user roles if not already defined elsewhere
enum UserRole { worker, accountant, manager, admin, developer }

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _currentPasswordController = TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  
  bool _isLoading = false;
  bool _isEditMode = false;
  bool _isChangingPassword = false;
  File? _profileImage;
  
  @override
  void initState() {
    super.initState();
    _initializeUserData();
  }
  
  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
  
  /// Loads the current user data from the auth provider
  Future<void> _initializeUserData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final currentUser = authProvider.currentUser;
    
    if (currentUser != null) {
      setState(() {
        _nameController.text = currentUser.name;
        _emailController.text = currentUser.email;
      });
    }
  }
  
  /// Handles picking an image from gallery or camera
  Future<void> _pickImage(ImageSource source) async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? pickedFile = await picker.pickImage(source: source);
      
      if (pickedFile != null) {
        setState(() {
          _profileImage = File(pickedFile.path);
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error picking image. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  /// Displays a dialog to choose image source
  void _showImagePickerOptions() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.backgroundDark,
          title: const Text('Choose an option', style: TextStyle(color: Colors.white)),
          content: SingleChildScrollView(
            child: ListBody(
              children: [
                ListTile(
                  leading: const Icon(Icons.photo_library, color: AppColors.primaryBlue),
                  title: const Text('Gallery', style: TextStyle(color: Colors.white)),
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.gallery);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.camera_alt, color: AppColors.primaryBlue),
                  title: const Text('Camera', style: TextStyle(color: Colors.white)),
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.camera);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  
  /// Updates the user profile information
  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    setState(() => _isLoading = true);
    
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      // Changed User to UserModel to match your model class
      final updatedUser = UserModel(
        id: authProvider.currentUser!.id,
        name: _nameController.text,
        email: _emailController.text,
        role: authProvider.currentUser!.role,
        password: authProvider.currentUser!.password, // Maintain existing password
        avatarUrl: authProvider.currentUser!.avatarUrl, // Maintain existing avatarUrl
      );
      
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Update user in provider
      await authProvider.updateUserProfile(updatedUser);
      
      setState(() {
        _isEditMode = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile updated successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error updating profile: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }
  
  /// Handles changing user password
  Future<void> _changePassword() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    setState(() => _isLoading = true);
    
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      
      // Verify current password matches
      if (authProvider.currentUser!.password != _currentPasswordController.text) {
        throw Exception('Current password is incorrect');
      }
      
      // Verify new passwords match
      if (_newPasswordController.text != _confirmPasswordController.text) {
        throw Exception('New passwords do not match');
      }
      
      // Create updated user with new password
      // Changed User to UserModel to match your model class
      final updatedUser = UserModel(
        id: authProvider.currentUser!.id,
        name: authProvider.currentUser!.name,
        email: authProvider.currentUser!.email,
        role: authProvider.currentUser!.role,
        password: _newPasswordController.text,
        avatarUrl: authProvider.currentUser!.avatarUrl, // Include avatarUrl
      );
      
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Update user in provider
      await authProvider.updateUserPassword(updatedUser);
      
      // Clear password fields
      _currentPasswordController.clear();
      _newPasswordController.clear();
      _confirmPasswordController.clear();
      
      setState(() {
        _isChangingPassword = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Password changed successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error changing password: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, _) {
        final currentUser = authProvider.currentUser;
        
        if (currentUser == null) {
          return const Scaffold(
            body: Center(
              child: Text('No user logged in', style: TextStyle(color: Colors.white)),
            ),
          );
        }
        
        return Scaffold(
          appBar: AppBar(
            title: const Text('User Profile'),
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  // Show search
                },
              ),
            ],
          ),
          drawer: const AppDrawer(currentRoute: RoutePaths.profile),

          body: _isLoading 
            ? const Center(child: LoadingIndicator()) 
            : SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Profile Picture Section
                      _buildProfilePicture(currentUser),
                      const SizedBox(height: 24),
                      
                      // Role Badge
                      _buildRoleBadge(_mapStringToUserRole(currentUser.role)),
                      const SizedBox(height: 24),
                      
                      // Information Section
                      if (_isEditMode) 
                        _buildEditProfileForm()
                      else if (_isChangingPassword)
                        _buildChangePasswordForm()
                      else
                        _buildProfileInfo(currentUser),
                      
                      const SizedBox(height: 32),
                      
                      // Action Buttons
                      _buildActionButtons(),
                    ],
                  ),
                ),
              ),
        );
      },
    );
  }
  
  /// Confirm logout dialog
  void _confirmLogout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.backgroundDark,
        title: const Text('Confirm Logout', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to logout?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                  ),
                  child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
                ),
                const SizedBox(width: 16.0),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                  ),
                  onPressed: () {
                    // Get the auth provider
                    final authProvider = Provider.of<AuthProvider>(context, listen: false);
                    
                    // Call logout method from provider (same as in app_drawer.dart)
                    authProvider.logout();
                    
                    // Close the dialog
                    Navigator.pop(context);
                    
                    // Navigate to login screen
                    context.go(RoutePaths.login);
                  },
                  child: const Text('Logout'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the profile picture section with edit option
  Widget _buildProfilePicture(UserModel user) {
    return Stack(
      alignment: Alignment.bottomRight,
      children: [
        CircleAvatar(
          radius: 60,
          backgroundColor: AppColors.primaryBlue.withOpacity(0.3), // Changed from primaryBlueLight to primaryBlue with opacity
          backgroundImage: _profileImage != null 
            ? FileImage(_profileImage!) as ImageProvider 
            : (user.avatarUrl.isNotEmpty 
                ? NetworkImage(user.avatarUrl) as ImageProvider
                : const AssetImage('assets/images/avatar_placeholder.png')),
          child: (_profileImage == null && user.avatarUrl.isEmpty)
            ? Icon(
                Icons.person,
                size: 80,
                color: AppColors.backgroundDark.withOpacity(0.6),
              ) 
            : null,
        ),
        if (_isEditMode)
          GestureDetector(
            onTap: _showImagePickerOptions,
            child: CircleAvatar(
              radius: 20,
              backgroundColor: AppColors.primaryBlue,
              child: const Icon(
                Icons.camera_alt,
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
      ],
    );
  }
  
  /// Helper method to convert string role to UserRole enum
  UserRole _mapStringToUserRole(String role) {
    switch (role.toLowerCase()) {
      case 'worker':
        return UserRole.worker;
      case 'accountant':
        return UserRole.accountant;
      case 'manager':
        return UserRole.manager;
      case 'admin':
        return UserRole.admin;
      case 'developer':
        return UserRole.developer;
      default:
        return UserRole.worker; // Default case
    }
  }
  
  /// Builds a color-coded badge displaying the user's role
  Widget _buildRoleBadge(UserRole role) {
    Color badgeColor;
    
    switch (role) {
      case UserRole.worker:
        badgeColor = Colors.green;
        break;
      case UserRole.accountant:
        badgeColor = Colors.blue;
        break;
      case UserRole.manager:
        badgeColor = Colors.purple;
        break;
      case UserRole.admin:
        badgeColor = Colors.orange;
        break;
      case UserRole.developer:
        badgeColor = Colors.red;
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: badgeColor, width: 1),
      ),
      child: Text(
        role.toString().split('.').last.toUpperCase(),
        style: TextStyle(
          color: badgeColor,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  /// Displays the user information in read-only mode
  Widget _buildProfileInfo(UserModel user) {
    return Column(
      children: [
        // User ID
        ListTile(
          leading: const Icon(Icons.badge, color: AppColors.primaryBlue),
          title: const Text('User ID', style: TextStyle(color: Colors.white70)),
          subtitle: Text(user.id.toString(), style: const TextStyle(color: Colors.white)),
        ),
        const Divider(color: Colors.white24),
        
        // Name
        ListTile(
          leading: const Icon(Icons.person, color: AppColors.primaryBlue),
          title: const Text('Name', style: TextStyle(color: Colors.white70)),
          subtitle: Text(user.name, style: const TextStyle(color: Colors.white)),
        ),
        const Divider(color: Colors.white24),
        
        // Email
        ListTile(
          leading: const Icon(Icons.email, color: AppColors.primaryBlue),
          title: const Text('Email', style: TextStyle(color: Colors.white70)),
          subtitle: Text(user.email, style: const TextStyle(color: Colors.white)),
        ),
        const Divider(color: Colors.white24),
        
        // Role with Permissions Info
        ListTile(
          leading: const Icon(Icons.security, color: AppColors.primaryBlue),
          title: const Text('Role & Permissions', style: TextStyle(color: Colors.white70)),
          subtitle: Text(
            _getRoleDescription(_mapStringToUserRole(user.role)), 
            style: const TextStyle(color: Colors.white)
          ),
        ),
      ],
    );
  }
  
  /// Builds the form for editing profile information
  Widget _buildEditProfileForm() {
    return Column(
      children: [
        // Name Field
        TextFormField(
          controller: _nameController,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            labelText: 'Name',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.person, color: AppColors.primaryBlue),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.primaryBlue),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter your name';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        
        // Email Field
        TextFormField(
          controller: _emailController,
          style: const TextStyle(color: Colors.white),
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
            labelText: 'Email',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.email, color: AppColors.primaryBlue),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.primaryBlue),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter your email';
            }
            // Basic email validation
            if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
              return 'Please enter a valid email address';
            }
            return null;
          },
        ),
        const SizedBox(height: 24),
        
        // Save & Cancel Buttons
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  _isEditMode = false;
                  // Reset controllers to original values
                  _initializeUserData();
                });
              },
              icon: const Icon(Icons.cancel),
              label: const Text('Cancel'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey,
                foregroundColor: Colors.white,
              ),
            ),
            ElevatedButton.icon(
              onPressed: _updateProfile,
              icon: const Icon(Icons.save),
              label: const Text('Save Changes'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  /// Builds the form for changing password
  Widget _buildChangePasswordForm() {
    return Column(
      children: [
        // Current Password
        TextFormField(
          controller: _currentPasswordController,
          style: const TextStyle(color: Colors.white),
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Current Password',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.lock, color: AppColors.primaryBlue),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.primaryBlue),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter your current password';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        
        // New Password
        TextFormField(
          controller: _newPasswordController,
          style: const TextStyle(color: Colors.white),
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'New Password',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.lock_outline, color: AppColors.primaryBlue),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.primaryBlue),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter a new password';
            }
            if (value.length < 6) {
              return 'Password must be at least 6 characters';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        
        // Confirm Password
        TextFormField(
          controller: _confirmPasswordController,
          style: const TextStyle(color: Colors.white),
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Confirm New Password',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.lock_outline, color: AppColors.primaryBlue),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.primaryBlue),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please confirm your new password';
            }
            if (value != _newPasswordController.text) {
              return 'Passwords do not match';
            }
            return null;
          },
        ),
        const SizedBox(height: 24),
        
        // Save & Cancel Buttons
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  _isChangingPassword = false;
                  _currentPasswordController.clear();
                  _newPasswordController.clear();
                  _confirmPasswordController.clear();
                });
              },
              icon: const Icon(Icons.cancel),
              label: const Text('Cancel'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey,
                foregroundColor: Colors.white,
              ),
            ),
            ElevatedButton.icon(
              onPressed: _changePassword,
              icon: const Icon(Icons.key),
              label: const Text('Change Password'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  /// Builds the action buttons for the profile screen based on current mode
  Widget _buildActionButtons() {
    // Don't show action buttons when in edit or password change mode
    if (_isEditMode || _isChangingPassword) {
      return const SizedBox.shrink();
    }
    
    return Column(
      children: [
        ElevatedButton.icon(
          onPressed: () {
            setState(() {
              _isEditMode = true;
            });
          },
          icon: const Icon(Icons.edit),
          label: const Text('Edit Profile'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBlue,
            foregroundColor: Colors.white,
            minimumSize: const Size(200, 45),
          ),
        ),
        const SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: () {
            setState(() {
              _isChangingPassword = true;
            });
          },
          icon: const Icon(Icons.lock_outline),
          label: const Text('Change Password'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.grey.shade800,
            foregroundColor: Colors.white,
            minimumSize: const Size(200, 45),
          ),
        ),
        const SizedBox(height: 16),
        TextButton.icon(
          onPressed: () {
            _confirmLogout();
          },
          icon: const Icon(Icons.logout, color: Colors.redAccent),
          label: const Text('Logout', style: TextStyle(color: Colors.redAccent)),
        ),
      ],
    );
  }
  
  /// Returns a description of permissions based on user role
  String _getRoleDescription(UserRole role) {
    switch (role) {
      case UserRole.worker:
        return 'Worker: Access to dashboard and task planner only.';
      case UserRole.accountant:
        return 'Accountant: Access to dashboard, inventory management, and task planner.';
      case UserRole.manager:
        return 'Manager: Access to dashboard, inventory, projects, and task planner.';
      case UserRole.admin:
        return 'Admin: Full access to all features including user management.';
      case UserRole.developer:
        return 'Developer: Complete system access including developer tools.';
    }
  }
  
  /// Helper method to check if user has an avatar
  bool _hasAvatar(UserModel user) {
    return user.avatarUrl.isNotEmpty;
  }
}