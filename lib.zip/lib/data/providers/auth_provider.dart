import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../../mock_data/mock_users.dart';

/// Provider class responsible for managing authentication state throughout the app.
///
/// This class handles user login, logout, and maintains the current authentication state.
/// It extends ChangeNotifier to notify listeners when the authentication state changes.
class AuthProvider with ChangeNotifier {
  /// Current logged-in user (null if not logged in)
  UserModel? _currentUser;
  
  /// Authentication token received from backend
  String? _token;
  
  /// Loading state flag for authentication operations
  bool _isLoading = false;
  
  /// Error message from the most recent authentication operation
  String? _errorMessage;

  /// Returns the current user, or null if not logged in
  UserModel? get currentUser => _currentUser;
  
  /// Returns true if a user is currently logged in
  bool get isLoggedIn => _currentUser != null;
  
  /// Returns the authentication token
  String? get token => _token;
  
  /// Returns true if an authentication operation is in progress
  bool get isLoading => _isLoading;
  
  /// Returns the error message from the most recent authentication operation
  String? get errorMessage => _errorMessage;
  
  /// Returns the user's role, or an empty string if not logged in
  String get userRole => _currentUser?.role ?? '';

  /// Authenticates a user with the provided email and password.
  ///
  /// This implementation uses the mock user data for authentication.
  /// Checks if the provided credentials match any user in the mock database.
  /// Returns true on successful login, false otherwise.
  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    
    try {
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Basic validation
      if (email.isEmpty || password.isEmpty) {
        throw Exception('Email and password cannot be empty');
      }
      
      // Find user by credentials using the helper function from mock_users.dart
      final user = findUserByCredentials(email, password);
      
      if (user != null) {
        // Successful login
        _currentUser = user;
        // Generate a mock token with timestamp for simulated authentication
        _token = 'dummy_token_${DateTime.now().millisecondsSinceEpoch}';
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        // Failed login - no matching user found
        throw Exception('Invalid email or password');
      }
    } catch (e) {
      // Handle any errors during the login process
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Logs out the current user.
  ///
  /// Clears user data and authentication token.
  Future<void> logout() async {
    _isLoading = true;
    notifyListeners();
    
    // Simulate network delay for logout request
    await Future.delayed(const Duration(milliseconds: 500));
    
    _currentUser = null;
    _token = null;
    _isLoading = false;
    _errorMessage = null;
    
    notifyListeners();
  }

  /// Clears any authentication errors.
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
  
  /// Checks if the current user has the required role.
  ///
  /// Returns true if the user is logged in and has the specified role.
  bool hasRole(String role) {
    return isLoggedIn && _currentUser!.role == role;
  }
  
  /// Checks if the current user has at least the specified access level.
  ///
  /// Based on the hierarchy: Worker < Accountant < Manager < Admin < Developer
  bool hasAccessLevel(String minimumRole) {
    if (!isLoggedIn) return false;
    
    // Define role hierarchy (higher index = higher access)
    const roles = ['Worker', 'Accountant', 'Manager', 'Admin', 'Developer'];
    
    int userRoleIndex = roles.indexOf(_currentUser!.role);
    int requiredRoleIndex = roles.indexOf(minimumRole);
    
    // If either role is not found in our hierarchy, default behavior
    if (userRoleIndex == -1 || requiredRoleIndex == -1) {
      return _currentUser!.role == minimumRole;
    }
    
    // Check if user's role index is greater than or equal to required role index
    return userRoleIndex >= requiredRoleIndex;
  }
  
  /// Updates the user profile information.
  ///
  /// This method is called when a user edits their profile information.
  /// It updates the user data and notifies listeners of the change.
  Future<void> updateUserProfile(UserModel updatedUser) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    
    try {
      // Simulate network delay for API call
      await Future.delayed(const Duration(seconds: 1));
      
      // In a real app, this would make an API call to update the user on the server
      // For now, we'll just update our local user object
      
      // Validate email format
      if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(updatedUser.email)) {
        throw Exception('Invalid email format');
      }
      
      // Update the current user with the new information
      _currentUser = updatedUser;
      
      // In a real app, you would also update the user in your mock_users list
      // updateMockUser(updatedUser);
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      throw e; // Re-throw to allow the UI to handle the error
    }
  }
  
  /// Updates the user's password.
  ///
  /// This method is called when a user changes their password.
  /// It updates the password and notifies listeners of the change.
  Future<void> updateUserPassword(UserModel updatedUser) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    
    try {
      // Simulate network delay for API call
      await Future.delayed(const Duration(seconds: 1));
      
      // In a real app, this would make an API call to update the password on the server
      // Basic password validation
      if (updatedUser.password.length < 6) {
        throw Exception('Password must be at least 6 characters long');
      }
      
      // Update the current user with the new password
      _currentUser = updatedUser;
      
      // In a real app, you would also update the user in your mock_users list
      // updateMockUserPassword(updatedUser);
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      throw e; // Re-throw to allow the UI to handle the error
    }
  }
  
  /// Updates user avatar.
  ///
  /// This method would typically upload the image to a server and
  /// update the avatar URL in the user profile.
  Future<void> updateUserAvatar(String imagePath) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    
    try {
      // Simulate network delay for image upload
      await Future.delayed(const Duration(seconds: 2));
      
      // In a real app, this would:
      // 1. Upload the image to a server/storage
      // 2. Get back the URL of the uploaded image
      // 3. Update the user profile with the new avatar URL
      
      if (_currentUser != null) {
        // Create a new user object with the updated avatar URL
        _currentUser = _currentUser!.copyWith(
          avatarUrl: 'https://example.com/avatars/${_currentUser!.id}.jpg',
        );
      }
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      throw e;
    }
  }
}