import 'package:flutter/material.dart';

/// Provider class responsible for managing theme settings throughout the app.
///
/// This class handles theme toggling between light and dark modes,
/// and maintains the current theme state. It extends ChangeNotifier
/// to notify listeners when the theme changes.
class ThemeProvider with ChangeNotifier {
  /// Flag indicating whether dark mode is currently active
  bool _isDarkMode = true;
  
  /// Current theme accent color
  Color _accentColor = Colors.blue;

  /// Returns true if dark mode is active
  bool get isDarkMode => _isDarkMode;
  
  /// Returns the current accent color
  Color get accentColor => _accentColor;

  /// Returns the appropriate theme mode
  ThemeMode get themeMode => _isDarkMode ? ThemeMode.dark : ThemeMode.light;

  /// Toggles between light and dark mode.
  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }
  
  /// Sets dark mode to a specific value.
  void setDarkMode(bool value) {
    if (_isDarkMode != value) {
      _isDarkMode = value;
      notifyListeners();
    }
  }
  
  /// Updates the accent color.
  ///
  /// The accent color is used for buttons, selections, and highlighting.
  void setAccentColor(Color color) {
    if (_accentColor != color) {
      _accentColor = color;
      notifyListeners();
    }
  }
  
  /// Returns a color that contrasts well with the current theme.
  ///
  /// This is useful for ensuring text is visible against various backgrounds.
  Color getContrastColor() {
    return _isDarkMode ? Colors.white : Colors.black;
  }
  
  /// Returns the appropriate background color based on the current theme.
  Color get backgroundColor => _isDarkMode 
      ? const Color(0xFF121212) // Dark background 
      : Colors.white; // Light background
  
  /// Returns the appropriate card color based on the current theme.
  Color get cardColor => _isDarkMode 
      ? const Color(0xFF1E1E1E) // Dark card
      : Colors.white; // Light card
      
  /// Returns the appropriate text color based on the current theme.
  Color get textColor => _isDarkMode 
      ? Colors.white // Dark mode text
      : Colors.black; // Light mode text
      
  /// Returns the appropriate secondary text color based on the current theme.
  Color get secondaryTextColor => _isDarkMode 
      ? Colors.white70 // Dark mode secondary text
      : Colors.black54; // Light mode secondary text
}