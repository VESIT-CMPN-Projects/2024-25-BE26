/// Represents a construction project in the Mobile Operations App.
///
/// This model contains all essential project information including timeline,
/// description, and current status for tracking and management purposes.
class ProjectModel {
  /// Unique identifier for the project
  final int id;
  
  /// Title/name of the project
  final String title;
  
  /// Detailed description of the project
  final String description;
  
  /// Project commencement date
  final DateTime startDate;
  
  /// Project expected completion date
  final DateTime endDate;
  
  /// Current status of the project (e.g., "Pending", "In Progress", "Completed", "Delayed")
  final String status;

  /// Creates a new instance of [ProjectModel].
  ///
  /// All fields are required to ensure consistent project tracking.
  const ProjectModel({
    required this.id,
    required this.title,
    required this.description,
    required this.startDate,
    required this.endDate,
    required this.status,
  });

  /// Creates a [ProjectModel] instance from a JSON map.
  ///
  /// This factory constructor facilitates deserialization of project data
  /// from API responses or local storage. Handles DateTime conversion from strings.
  factory ProjectModel.fromJson(Map<String, dynamic> json) {
    return ProjectModel(
      id: json['id'] as int,
      title: json['title'] as String,
      description: json['description'] as String,
      startDate: DateTime.parse(json['startDate'] as String),
      endDate: DateTime.parse(json['endDate'] as String),
      status: json['status'] as String,
    );
  }

  /// Converts this [ProjectModel] instance to a JSON map.
  ///
  /// This method facilitates serialization for API requests or local storage.
  /// DateTime objects are converted to ISO 8601 strings.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'status': status,
    };
  }

  /// Creates a copy of this [ProjectModel] with specified fields replaced with new values.
  ProjectModel copyWith({
    int? id,
    String? title,
    String? description,
    DateTime? startDate,
    DateTime? endDate,
    String? status,
  }) {
    return ProjectModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      status: status ?? this.status,
    );
  }

  @override
  String toString() {
    return 'ProjectModel(id: $id, title: $title, status: $status)';
  }
}