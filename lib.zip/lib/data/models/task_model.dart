/// Represents a task in the Mobile Operations App system.
///
/// This model contains all essential task information including project association,
/// deadline, and status for task tracking and management.
class TaskModel {
  /// Unique identifier for the task
  final int id;
  
  /// ID of the associated project
  final int projectId;
  
  /// Title/name of the task
  final String title;
  
  /// Detailed description of the task and requirements
  final String description;
  
  /// Deadline by which the task should be completed
  final DateTime deadline;
  
  /// Current status of the task (e.g., "Pending", "In Progress", "Completed", "Delayed")
  final String status;

  /// Creates a new instance of [TaskModel].
  ///
  /// All fields are required to ensure consistent task tracking.
  const TaskModel({
    required this.id,
    required this.projectId,
    required this.title,
    required this.description,
    required this.deadline,
    required this.status,
  });

  /// Creates a [TaskModel] instance from a JSON map.
  ///
  /// This factory constructor facilitates deserialization of task data
  /// from API responses or local storage. Handles DateTime conversion from strings.
  factory TaskModel.fromJson(Map<String, dynamic> json) {
    return TaskModel(
      id: json['id'] as int,
      projectId: json['projectId'] as int,
      title: json['title'] as String,
      description: json['description'] as String,
      deadline: DateTime.parse(json['deadline'] as String),
      status: json['status'] as String,
    );
  }

  /// Converts this [TaskModel] instance to a JSON map.
  ///
  /// This method facilitates serialization for API requests or local storage.
  /// DateTime objects are converted to ISO 8601 strings.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'projectId': projectId,
      'title': title,
      'description': description,
      'deadline': deadline.toIso8601String(),
      'status': status,
    };
  }

  /// Determines if the task is overdue.
  ///
  /// Returns true if the current date is past the deadline and the task is not completed.
  bool isOverdue() {
    final now = DateTime.now();
    return now.isAfter(deadline) && status != 'Completed';
  }

  /// Creates a copy of this [TaskModel] with specified fields replaced with new values.
  TaskModel copyWith({
    int? id,
    int? projectId,
    String? title,
    String? description,
    DateTime? deadline,
    String? status,
  }) {
    return TaskModel(
      id: id ?? this.id,
      projectId: projectId ?? this.projectId,
      title: title ?? this.title,
      description: description ?? this.description,
      deadline: deadline ?? this.deadline,
      status: status ?? this.status,
    );
  }

  @override
  String toString() {
    return 'TaskModel(id: $id, projectId: $projectId, title: $title, status: $status)';
  }
}