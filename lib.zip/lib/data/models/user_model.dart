/// Represents a user in the Mobile Operations App system.
///
/// This model contains all essential user information including personal details,
/// role, password for authentication, and avatar URL for UI display purposes.
class UserModel {
  /// Unique identifier for the user
  final int id;
  /// Full name of the user
  final String name;
  /// Email address of the user, used for authentication and communications
  final String email;
  /// Password for user authentication
  final String password;
  /// User's role (e.g., Worker, Accountant, Manager, Admin, Developer)
  /// Determines system access permissions
  final String role;
  /// URL to the user's avatar image
  final String avatarUrl;

  /// Creates a new instance of [UserModel].
  ///
  /// All fields are required to ensure consistent data representation.
  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.role,
    required this.avatarUrl,
  });

  /// Creates a [UserModel] instance from a JSON map.
  ///
  /// This factory constructor facilitates deserialization of user data
  /// from API responses or local storage.
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as int,
      name: json['name'] as String,
      email: json['email'] as String,
      password: json['password'] as String,
      role: json['role'] as String,
      avatarUrl: json['avatarUrl'] as String,
    );
  }

  /// Converts this [UserModel] instance to a JSON map.
  ///
  /// This method facilitates serialization for API requests or local storage.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'password': password,
      'role': role,
      'avatarUrl': avatarUrl,
    };
  }

  /// Creates a copy of this [UserModel] with specified fields replaced with new values.
  UserModel copyWith({
    int? id,
    String? name,
    String? email,
    String? password,
    String? role,
    String? avatarUrl,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      password: password ?? this.password,
      role: role ?? this.role,
      avatarUrl: avatarUrl ?? this.avatarUrl,
    );
  }

  @override
  String toString() {
    // Note: We exclude password from toString for security reasons
    return 'UserModel(id: $id, name: $name, email: $email, role: $role)';
  }
}