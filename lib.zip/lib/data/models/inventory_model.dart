/// Represents an inventory item in the Mobile Operations App system.
///
/// This model contains all essential inventory information including
/// quantity tracking and alert thresholds for inventory management.
class InventoryModel {
  /// Unique identifier for the inventory item
  final int id;
  
  /// Name of the material (e.g., "Cement", "Sand", "Aggregate")
  final String materialName;
  
  /// Current quantity of the material in stock
  final double quantity;
  
  /// Minimum threshold that triggers low stock alerts
  final double alertThreshold;

  /// Creates a new instance of [InventoryModel].
  ///
  /// All fields are required to ensure consistent inventory tracking.
  const InventoryModel({
    required this.id,
    required this.materialName,
    required this.quantity,
    required this.alertThreshold,
  });

  /// Creates an [InventoryModel] instance from a JSON map.
  ///
  /// This factory constructor facilitates deserialization of inventory data
  /// from API responses or local storage.
  factory InventoryModel.fromJson(Map<String, dynamic> json) {
    return InventoryModel(
      id: json['id'] as int,
      materialName: json['materialName'] as String,
      quantity: json['quantity'] is int 
          ? (json['quantity'] as int).toDouble() 
          : json['quantity'] as double,
      alertThreshold: json['alertThreshold'] is int 
          ? (json['alertThreshold'] as int).toDouble() 
          : json['alertThreshold'] as double,
    );
  }

  /// Converts this [InventoryModel] instance to a JSON map.
  ///
  /// This method facilitates serialization for API requests or local storage.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'materialName': materialName,
      'quantity': quantity,
      'alertThreshold': alertThreshold,
    };
  }

  /// Determines if the current quantity is below the alert threshold.
  ///
  /// Returns true if the inventory quantity is less than or equal to the alert threshold.
  bool get isLow => quantity <= alertThreshold;

  /// Creates a copy of this [InventoryModel] with specified fields replaced with new values.
  InventoryModel copyWith({
    int? id,
    String? materialName,
    double? quantity,
    double? alertThreshold,
  }) {
    return InventoryModel(
      id: id ?? this.id,
      materialName: materialName ?? this.materialName,
      quantity: quantity ?? this.quantity,
      alertThreshold: alertThreshold ?? this.alertThreshold,
    );
  }

  @override
  String toString() {
    return 'InventoryModel(id: $id, materialName: $materialName, quantity: $quantity, isLow: $isLow)';
  }
}