import '../models/task_model.dart';
import '../../mock_data/mock_tasks.dart';

class TaskRepository {
  static final TaskRepository _instance = TaskRepository._internal();
  
  factory TaskRepository() {
    return _instance;
  }
  
  TaskRepository._internal();
  
  // Get all tasks
  List<TaskModel> getAllTasks() {
    return List.from(mockTasks);
  }
  
  // Get task by ID
  TaskModel? getTaskById(int id) {
    try {
      return mockTasks.firstWhere((task) => task.id == id);
    } catch (e) {
      return null;
    }
  }
  
  // Create a new task
  TaskModel createTask(TaskModel task) {
    // Find the highest ID to ensure uniqueness
    int highestId = 0;
    for (var t in mockTasks) {
      if (t.id > highestId) {
        highestId = t.id;
      }
    }
    
    // Create a new task with a unique ID
    final newTask = TaskModel(
      id: highestId + 1,
      projectId: task.projectId,
      title: task.title,
      description: task.description,
      deadline: task.deadline,
      status: task.status,
    );
    
    mockTasks.add(newTask);
    return newTask;
  }
  
  // Update an existing task
  bool updateTask(TaskModel updatedTask) {
    final index = mockTasks.indexWhere((task) => task.id == updatedTask.id);
    if (index != -1) {
      mockTasks[index] = updatedTask;
      return true;
    }
    return false;
  }
  
  // Delete a task
  bool deleteTask(int id) {
    final initialLength = mockTasks.length;
    mockTasks.removeWhere((task) => task.id == id);
    return mockTasks.length < initialLength;
  }
  
  // Update task status
  bool updateTaskStatus(int id, String newStatus) {
    final index = mockTasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      final task = mockTasks[index];
      mockTasks[index] = TaskModel(
        id: task.id,
        projectId: task.projectId,
        title: task.title,
        description: task.description,
        deadline: task.deadline,
        status: newStatus,
      );
      return true;
    }
    return false;
  }
  
  // Get tasks by project ID
  List<TaskModel> getTasksByProjectId(int projectId) {
    return mockTasks.where((task) => task.projectId == projectId).toList();
  }
  
  // Get tasks by status
  List<TaskModel> getTasksByStatus(String status) {
    return mockTasks.where((task) => task.status == status).toList();
  }
  
  // Get overdue tasks
  List<TaskModel> getOverdueTasks() {
    final now = DateTime.now();
    return mockTasks.where((task) => 
      task.deadline.isBefore(now) && task.status != 'Completed'
    ).toList();
  }
}